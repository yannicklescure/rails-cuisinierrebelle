(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[49],{

/***/ "./app/javascript/vue/views/UserFollowers.vue":
/*!****************************************************!*\
  !*** ./app/javascript/vue/views/UserFollowers.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _UserFollowers_vue_vue_type_template_id_5be3accc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./UserFollowers.vue?vue&type=template&id=5be3accc& */ "./app/javascript/vue/views/UserFollowers.vue?vue&type=template&id=5be3accc&");
/* harmony import */ var _UserFollowers_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UserFollowers.vue?vue&type=script&lang=js& */ "./app/javascript/vue/views/UserFollowers.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _UserFollowers_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _UserFollowers_vue_vue_type_template_id_5be3accc___WEBPACK_IMPORTED_MODULE_0__["render"],
  _UserFollowers_vue_vue_type_template_id_5be3accc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/views/UserFollowers.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/views/UserFollowers.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./app/javascript/vue/views/UserFollowers.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserFollowers_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--6-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserFollowers.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/UserFollowers.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_UserFollowers_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/views/UserFollowers.vue?vue&type=template&id=5be3accc&":
/*!***********************************************************************************!*\
  !*** ./app/javascript/vue/views/UserFollowers.vue?vue&type=template&id=5be3accc& ***!
  \***********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UserFollowers_vue_vue_type_template_id_5be3accc___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./UserFollowers.vue?vue&type=template&id=5be3accc& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/UserFollowers.vue?vue&type=template&id=5be3accc&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UserFollowers_vue_vue_type_template_id_5be3accc___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_UserFollowers_vue_vue_type_template_id_5be3accc___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/UserFollowers.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/views/UserFollowers.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
 // import Card from '../components/Card.vue'
// import Follow from '../components/buttons/Follow.vue'
// import UserBanner from '../components/UserBanner.vue'
// import UserCard from '../components/UserCard.vue'

var Card = function Card() {
  return __webpack_require__.e(/*! import() */ 0).then(__webpack_require__.bind(null, /*! ../components/Card.vue */ "./app/javascript/vue/components/Card.vue"));
};

var Follow = function Follow() {
  return __webpack_require__.e(/*! import() */ 2).then(__webpack_require__.bind(null, /*! ../components/buttons/Follow.vue */ "./app/javascript/vue/components/buttons/Follow.vue"));
};

var UserBanner = function UserBanner() {
  return __webpack_require__.e(/*! import() */ 1).then(__webpack_require__.bind(null, /*! ../components/UserBanner.vue */ "./app/javascript/vue/components/UserBanner.vue"));
};

var UserCard = function UserCard() {
  return __webpack_require__.e(/*! import() */ 3).then(__webpack_require__.bind(null, /*! ../components/UserCard.vue */ "./app/javascript/vue/components/UserCard.vue"));
};

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'UserFollowers',
  data: function data() {
    return {
      componentKey: 0,
      // navbarHeight: 0,
      data: [],
      busy: false
    };
  },
  components: {
    Card: Card,
    Follow: Follow,
    UserBanner: UserBanner,
    UserCard: UserCard
  },
  methods: {
    // cardParams (value) {
    //   const cardWidth = value.params.width
    //   console.log(cardWidth)
    //   const containerWidth = this.$refs.container.offsetWidth
    //   console.log(containerWidth)
    //   console.log(containerWidth / cardWidth)
    // },
    getUsers: function getUsers() {
      this.$store.dispatch('USERS', {}).then(function (response) {
        console.log(response);
      });
    },
    loadMore: function loadMore() {
      var _this = this;

      if (this.data.length < this.followers.length) {
        console.log('loadMore');
        this.busy = true;
        setTimeout(function () {
          var cards = 24;
          var min = _this.data.length;
          var max = min + cards <= _this.followers.length ? min + cards : _this.followers.length;

          for (var i = min, j = max; i < j; i++) {
            _this.data.push(_this.followers[i]);
          }

          _this.busy = false;
        }, 0);
      }
    }
  },
  computed: _objectSpread(_objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapGetters"])(['navbarHeight', 'usersFilter'])), {}, {
    followers: function followers() {
      return this.usersFilter(this.$route.params.id).followers.data;
    }
  }),
  watch: {
    followers: function followers() {
      this.loadMore();
    }
  },
  created: function created() {
    if (this.followers && this.data.length === 0) this.loadMore(); // if (this.$store.getters.recipes) this.loadMore()
  },
  beforeMount: function beforeMount() {
    // console.log(this.$store.getters.recipes)
    this.getUsers();
  },
  mounted: function mounted() {
    this.$nextTick(function () {
      // this.navbarHeight = this.$store.getters.navbarHeight
      // console.log(this.$store.getters.navbarHeight)
      // console.log(this.$store.getters.recipes)
      // if (this.followers.length > 0) console.log('followers ready')
      setTimeout(function () {// this.loadMore()
        // while (!this.followers && this.data.length === 0) this.loadMore()
      }, 1000);
    });
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/UserFollowers.vue?vue&type=template&id=5be3accc&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/views/UserFollowers.vue?vue&type=template&id=5be3accc& ***!
  \*****************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { style: { paddingTop: _vm.navbarHeight + "px" } },
    [
      _c("user-banner"),
      _vm._v(" "),
      _c("div", { ref: "container", staticClass: "container" }, [
        _c("div", { staticClass: "px-md-3 px-md-5" }, [
          _c(
            "table",
            { staticClass: "table table-borderless" },
            _vm._l(_vm.data, function(item, index) {
              return _c(
                "tbody",
                { key: item.id },
                [_c("user-card", { attrs: { item: item } })],
                1
              )
            }),
            0
          ),
          _vm._v(" "),
          _c("div", {
            directives: [
              {
                name: "infinite-scroll",
                rawName: "v-infinite-scroll",
                value: _vm.loadMore,
                expression: "loadMore"
              }
            ],
            attrs: {
              "infinite-scroll-disabled": "busy",
              "infinite-scroll-distance": "navbarHeight",
              "infinite-scroll-immediate-check": "true"
            }
          })
        ])
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=49-f72e2b95c83407153277.chunk.js.map