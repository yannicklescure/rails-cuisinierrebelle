(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[39],{

/***/ "./app/javascript/vue/views/Login.vue":
/*!********************************************!*\
  !*** ./app/javascript/vue/views/Login.vue ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Login_vue_vue_type_template_id_3b055cf9___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Login.vue?vue&type=template&id=3b055cf9& */ "./app/javascript/vue/views/Login.vue?vue&type=template&id=3b055cf9&");
/* harmony import */ var _Login_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Login.vue?vue&type=script&lang=js& */ "./app/javascript/vue/views/Login.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Login_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Login_vue_vue_type_template_id_3b055cf9___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Login_vue_vue_type_template_id_3b055cf9___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/views/Login.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/views/Login.vue?vue&type=script&lang=js&":
/*!*********************************************************************!*\
  !*** ./app/javascript/vue/views/Login.vue?vue&type=script&lang=js& ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Login_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--6-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Login.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Login.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Login_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/views/Login.vue?vue&type=template&id=3b055cf9&":
/*!***************************************************************************!*\
  !*** ./app/javascript/vue/views/Login.vue?vue&type=template&id=3b055cf9& ***!
  \***************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Login_vue_vue_type_template_id_3b055cf9___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Login.vue?vue&type=template&id=3b055cf9& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Login.vue?vue&type=template&id=3b055cf9&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Login_vue_vue_type_template_id_3b055cf9___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Login_vue_vue_type_template_id_3b055cf9___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Login.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/views/Login.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


var capitalize = function capitalize(s) {
  if (typeof s !== 'string') return '';
  return s.charAt(0).toUpperCase() + s.slice(1);
};

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Login',
  data: function data() {
    return {
      disabled: true,
      email: null,
      password: null,
      errors: []
    };
  },
  // components: {
  //   // Navbar
  // },
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapGetters"])(['navbarHeight'])),
  methods: {
    allowPost: function allowPost() {
      if (this.email && this.password) this.disabled = false;else this.disabled = true;
    },
    showPassword: function showPassword() {
      var _this = this;

      if (this.$refs.password.type === "text") {
        this.$refs.password.type = "password";
        this.$refs.passwordIcon.innerText = "visibility_off";
      } else {
        this.$refs.password.type = "text";
        this.$refs.passwordIcon.innerText = "visibility";
        setTimeout(function () {
          _this.showPassword();
        }, 3000);
      }
    },
    validateEmail: function validateEmail(email) {
      var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      return re.test(String(email).toLowerCase());
    },
    checkForm: function checkForm() {
      this.errors = [];

      if (!this.email) {
        this.errors.push(this.$t('signUp.errors.email'));
        return false;
      }

      if (!this.validateEmail(this.email)) {
        this.errors.push(this.$t('signUp.errors.emailFormat'));
        return false;
      }

      if (!this.password) {
        this.errors.push(this.$t('signUp.errors.password'));
        return false;
      }

      if (this.password.split('').length < 3) {
        this.errors.push(this.$t('signUp.errors.passwordLength'));
        return false;
      } // if (this.password != this.confirmation) {
      //   this.errors.push(this.$t('signUp.errors.confirmation'))
      //   return false
      // }


      return true;
    },
    login: function login() {
      var _this2 = this;

      var checkForm = this.checkForm();

      if (checkForm) {
        console.log(this.email);
        var user = {
          email: this.email,
          password: this.password
        };
        this.$store.dispatch('LOG_IN', user).then(function (result) {
          console.log(result);

          if (result.status === 200) {
            console.log(capitalize(result.data.first_name));

            _this2.$toast.open({
              message: _this2.$t('login.welcome', {
                firstName: capitalize(result.data.first_name)
              }),
              type: 'success',
              // success, info, warning, error, default
              // all of other options may go here
              position: 'bottom',
              // top, bottom, top-right, bottom-right,top-left, bottom-left
              duration: 3000,
              // Visibility duration in milliseconds
              dismissible: true
            });

            _this2.$router.push({
              name: 'Home'
            });
          } else if (result.response) {
            // client received an error response (5xx, 4xx)
            _this2.errors.push(result.status);
          } else if (result.request) {
            // client never received a response, or request never left
            _this2.errors.push(result.status);
          } else {
            // anything else
            _this2.errors.push(result);
          }
        }).then(function () {
          if (_this2.errors.length > 0) {
            console.log(_this2.errors);

            _this2.$toast.open({
              message: _this2.errors[0],
              type: 'error',
              // success, info, warning, error, default
              // all of other options may go here
              position: 'bottom',
              // top, bottom, top-right, bottom-right,top-left, bottom-left
              duration: 3000,
              // Visibility duration in milliseconds
              dismissible: true
            });
          }
        });
      } else {
        console.log(this.errors);
        this.$toast.open({
          message: this.errors[0],
          type: 'error' // success, info, warning, error, default
          // all of other options may go here
          // position: 'bottom-right', // top, bottom, top-right, bottom-right,top-left, bottom-left
          // duration: 3000, // Visibility duration in milliseconds
          // dismissible: true,

        });
      }
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Login.vue?vue&type=template&id=3b055cf9&":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/views/Login.vue?vue&type=template&id=3b055cf9& ***!
  \*********************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "container d-flex cr-vh100",
      style: { paddingTop: _vm.navbarHeight + "px" }
    },
    [
      _c(
        "div",
        {
          staticClass:
            "d-flex flex-grow-1 justify-content-center align-items-center"
        },
        [
          _c("div", { staticClass: "d-flex flex-column w-md-50" }, [
            _c("form", [
              _c("div", { staticClass: "form-group my-2" }, [
                _c("label", { attrs: { for: "inputEmail" } }, [
                  _vm._v(_vm._s(_vm.$t("login.email")))
                ]),
                _vm._v(" "),
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.email,
                      expression: "email"
                    }
                  ],
                  staticClass: "form-control",
                  attrs: {
                    type: "email",
                    id: "inputEmail",
                    "aria-describedby": "emailHelp"
                  },
                  domProps: { value: _vm.email },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.email = $event.target.value
                    }
                  }
                }),
                _vm._v(" "),
                _c(
                  "small",
                  {
                    staticClass: "form-text text-muted",
                    attrs: { id: "emailHelp" }
                  },
                  [_vm._v(_vm._s(_vm.$t("login.disclaimer")))]
                )
              ]),
              _vm._v(" "),
              _c("label", { attrs: { for: "inputPassword" } }, [
                _vm._v(_vm._s(_vm.$t("signUp.password")))
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "input-group mb-3" }, [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.password,
                      expression: "password"
                    }
                  ],
                  ref: "password",
                  staticClass: "form-control",
                  attrs: {
                    type: "password",
                    "aria-describedby": "button-password"
                  },
                  domProps: { value: _vm.password },
                  on: {
                    input: [
                      function($event) {
                        if ($event.target.composing) {
                          return
                        }
                        _vm.password = $event.target.value
                      },
                      _vm.allowPost
                    ],
                    touchend: _vm.allowPost
                  }
                }),
                _vm._v(" "),
                _c("div", { staticClass: "input-group-append" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn btn-outline-form",
                      attrs: { type: "button", id: "button-password" },
                      on: { click: _vm.showPassword }
                    },
                    [
                      _c(
                        "i",
                        {
                          ref: "passwordIcon",
                          staticClass: "material-icons md-18 d-flex"
                        },
                        [_vm._v("visibility_off")]
                      )
                    ]
                  )
                ])
              ]),
              _vm._v(" "),
              _c("div", { staticClass: "d-flex justify-content-end" }, [
                _c(
                  "button",
                  {
                    staticClass: "btn btn-dark my-2 w-100",
                    attrs: { type: "submit", disabled: _vm.disabled },
                    on: {
                      click: function($event) {
                        $event.stopPropagation()
                        $event.preventDefault()
                        return _vm.login($event)
                      }
                    }
                  },
                  [_vm._v(_vm._s(_vm.$t("login.submit")))]
                )
              ])
            ]),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "my-3" },
              [
                _c("router-link", { attrs: { to: "/signup" } }, [
                  _vm._v(_vm._s(_vm.$t("login.signup")))
                ])
              ],
              1
            )
          ])
        ]
      )
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=39-d13cc0899dd2b5072051.chunk.js.map