(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[35],{

/***/ "./app/javascript/vue/components/comments/List.vue":
/*!*********************************************************!*\
  !*** ./app/javascript/vue/components/comments/List.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _List_vue_vue_type_template_id_ab914402___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./List.vue?vue&type=template&id=ab914402& */ "./app/javascript/vue/components/comments/List.vue?vue&type=template&id=ab914402&");
/* harmony import */ var _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./List.vue?vue&type=script&lang=js& */ "./app/javascript/vue/components/comments/List.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _List_vue_vue_type_template_id_ab914402___WEBPACK_IMPORTED_MODULE_0__["render"],
  _List_vue_vue_type_template_id_ab914402___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/components/comments/List.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/components/comments/List.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./app/javascript/vue/components/comments/List.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--6-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./List.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/comments/List.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/components/comments/List.vue?vue&type=template&id=ab914402&":
/*!****************************************************************************************!*\
  !*** ./app/javascript/vue/components/comments/List.vue?vue&type=template&id=ab914402& ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_ab914402___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./List.vue?vue&type=template&id=ab914402& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/comments/List.vue?vue&type=template&id=ab914402&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_ab914402___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_List_vue_vue_type_template_id_ab914402___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/comments/List.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/comments/List.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
 // import CommentForm from './New.vue'
// import Comment from './Show.vue'

var CommentForm = function CommentForm() {
  return __webpack_require__.e(/*! import() */ 14).then(__webpack_require__.bind(null, /*! ./New.vue */ "./app/javascript/vue/components/comments/New.vue"));
};

var Comment = function Comment() {
  return __webpack_require__.e(/*! import() */ 36).then(__webpack_require__.bind(null, /*! ./Show.vue */ "./app/javascript/vue/components/comments/Show.vue"));
};

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Comments',
  data: function data() {
    return {
      componentKey: 0,
      show: []
    };
  },
  components: {
    CommentForm: CommentForm,
    Comment: Comment
  },
  props: ['item'],
  computed: _objectSpread(_objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapGetters"])(['countRecipeComments', 'recipe'])), {}, {
    comments: function comments() {
      // return this.recipe(this.$route.params.id).comments.sort((a, b) => (a.timestamp > b.timestamp) ? 1 : -1).reverse()
      return this.item.comments.sort(function (a, b) {
        return a.timestamp > b.timestamp ? 1 : -1;
      }).reverse();
    },
    lastCommentId: function lastCommentId() {
      return this.comments[this.comments.length - 1].id;
    }
  }),
  methods: {
    lastCommentMounted: function lastCommentMounted(value) {
      this.$emit('lastCommentMounted', value);
    },
    commentNew: function commentNew(payload) {
      console.log(payload); // this.item.comments.push(payload.data)

      this.componentKey += 1;
    },
    commentReplyNew: function commentReplyNew(payload) {
      console.log(this.item);
      console.log(payload); // const comment = this.item.comments.filter(c => c.id === payload.data.id)[0]
      // const position = this.item.comments.indexOf(comment)
      // this.item.comments[position] = payload.data

      this.componentKey += 1;
    },
    commentDestroyed: function commentDestroyed(payload) {
      console.log(this.item);
      console.log(payload);
      this.componentKey += 1; // if (payload.type === 'comment') {
      //   console.log(`destroy comment ${ payload.comment_id }`)
      //   const comment = this.item.comments.filter(c => c.id === payload.comment_id)[0]
      //   const pos = this.item.comments.indexOf(comment)
      //   this.item.comments[pos].splice(pos, 1)
      // }
      // if (payload.type === 'reply') {
      //   // const recipe = state.data.recipes.filter(r => r.recipe.id === payload.recipe_id)[0]
      //   // console.log(recipe)
      //   // const position = state.data.recipes.indexOf(recipe)
      //   // console.log(position)
      //   console.log(`destroy reply ${ payload.id }`)
      //   const comment = this.item.comments.filter(c => c.id === payload.comment_id)[0]
      //   const pos = this.item.comments.indexOf(comment)
      //   const reply = this.item.comments[pos].replies.filter(r => r.id === payload.id)[0]
      //   const p = this.item.comments[pos].replies.indexOf(reply)
      //   this.item.comments[pos].replies.splice(p, 1)
      // }
    },
    showReplies: function showReplies(index) {
      console.log("comment ".concat(index, " ").concat(this.show[index])); // this.show[index] = !this.show[index]
      // https://stackoverflow.com/questions/41580617/vuejs-v-if-arrayindex-is-not-working

      this.$set(this.show, index, !this.show[index]);
    },
    initShow: function initShow() {
      // this.show = Array(this.item.comments.length).fill(false)
      this.show = _toConsumableArray(new Array(this.item.comments.length)).map(function () {
        return false;
      });
    }
  },
  mounted: function mounted() {
    var _this = this;

    this.$nextTick(function () {
      _this.initShow();

      _this.$emit('commentsReady', true);
    });
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/comments/List.vue?vue&type=template&id=ab914402&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/comments/List.vue?vue&type=template&id=ab914402& ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { key: _vm.componentKey, staticClass: "d-print-none mt-5" },
    [
      _c("div", { staticClass: "h4 mb-3" }, [
        _vm._v(
          _vm._s(
            _vm.$tc("recipe.comments.counts", _vm.countRecipeComments(_vm.item))
          )
        )
      ]),
      _vm._v(" "),
      _c("comment-form", {
        attrs: { item: _vm.item },
        on: { commentNew: _vm.commentNew }
      }),
      _vm._v(" "),
      _vm._l(_vm.comments, function(comment, i) {
        return _c(
          "div",
          { staticClass: "d-flex flex-column" },
          [
            _c("comment", {
              key: "c" + i,
              attrs: {
                item: comment,
                type: "comment",
                lastCommentId: _vm.lastCommentId
              },
              on: {
                commentDestroyed: _vm.commentDestroyed,
                commentReplyNew: _vm.commentReplyNew,
                lastCommentMounted: _vm.lastCommentMounted
              }
            }),
            _vm._v(" "),
            comment.replies.length
              ? _c(
                  "div",
                  {
                    staticClass: "d-flex mouse-pointer",
                    staticStyle: { "font-size": "90%" },
                    on: {
                      click: function($event) {
                        return _vm.showReplies(i)
                      }
                    }
                  },
                  [
                    _vm.show[i]
                      ? _c("span", { staticClass: "material-icons md-18" }, [
                          _vm._v("arrow_drop_up")
                        ])
                      : _vm._e(),
                    _vm._v(" "),
                    !_vm.show[i]
                      ? _c("span", { staticClass: "material-icons md-18" }, [
                          _vm._v("arrow_drop_down")
                        ])
                      : _vm._e(),
                    _vm._v(
                      "\n      " +
                        _vm._s(
                          _vm.$tc(
                            "recipe.comments.viewReplies",
                            comment.replies.length
                          )
                        ) +
                        "\n    "
                    )
                  ]
                )
              : _vm._e(),
            _vm._v(" "),
            _c("transition", { attrs: { name: "fade" } }, [
              _c(
                "div",
                {
                  directives: [
                    {
                      name: "show",
                      rawName: "v-show",
                      value: _vm.show[i],
                      expression: "show[i]"
                    }
                  ]
                },
                _vm._l(comment.replies, function(reply, j) {
                  return _c(
                    "div",
                    { staticClass: "d-flex align-items-start" },
                    [
                      _c("span", { staticClass: "material-icons md-18 mt-3" }, [
                        _vm._v("subdirectory_arrow_right")
                      ]),
                      _vm._v(" "),
                      _c("comment", {
                        key: "c" + i + "r" + j,
                        staticClass: "pl-3 flex-grow-1",
                        attrs: { item: reply, type: "reply" },
                        on: {
                          commentDestroyed: _vm.commentDestroyed,
                          commentReplyNew: _vm.commentReplyNew
                        }
                      })
                    ],
                    1
                  )
                }),
                0
              )
            ])
          ],
          1
        )
      })
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=35-c5fccd8de870d8ae2d0a.chunk.js.map