(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["hello_vue~._app_javascript_a"],{

/***/ "./app/javascript/app.vue":
/*!********************************!*\
  !*** ./app/javascript/app.vue ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _app_vue_vue_type_template_id_6fb8108a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.vue?vue&type=template&id=6fb8108a& */ "./app/javascript/app.vue?vue&type=template&id=6fb8108a&");
/* harmony import */ var _app_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.vue?vue&type=script&lang=js& */ "./app/javascript/app.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _app_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _app_vue_vue_type_template_id_6fb8108a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _app_vue_vue_type_template_id_6fb8108a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/app.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/app.vue?vue&type=script&lang=js&":
/*!*********************************************************!*\
  !*** ./app/javascript/app.vue?vue&type=script&lang=js& ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_app_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/babel-loader/lib??ref--6-0!../../node_modules/vue-loader/lib??vue-loader-options!./app.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/app.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_app_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/app.vue?vue&type=template&id=6fb8108a&":
/*!***************************************************************!*\
  !*** ./app/javascript/app.vue?vue&type=template&id=6fb8108a& ***!
  \***************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_app_vue_vue_type_template_id_6fb8108a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../node_modules/vue-loader/lib??vue-loader-options!./app.vue?vue&type=template&id=6fb8108a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/app.vue?vue&type=template&id=6fb8108a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_app_vue_vue_type_template_id_6fb8108a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_app_vue_vue_type_template_id_6fb8108a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./app/javascript/packs/hello_vue.js":
/*!*******************************************!*\
  !*** ./app/javascript/packs/hello_vue.js ***!
  \*******************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(global) {/* harmony import */ var node_fetch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! node-fetch */ "./node_modules/node-fetch/browser.js");
/* harmony import */ var node_fetch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(node_fetch__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue/dist/vue.esm */ "./node_modules/vue/dist/vue.esm.js");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var vue_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm.js");
/* harmony import */ var vue_meta__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! vue-meta */ "./node_modules/vue-meta/dist/vue-meta.esm.js");
/* harmony import */ var _vue_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../vue/store */ "./app/javascript/vue/store/index.js");
/* harmony import */ var _vue_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../vue/router */ "./app/javascript/vue/router/index.js");
/* harmony import */ var vuex_router_sync__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! vuex-router-sync */ "./node_modules/vuex-router-sync/index.js");
/* harmony import */ var vuex_router_sync__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(vuex_router_sync__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var vue_infinite_scroll__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! vue-infinite-scroll */ "./node_modules/vue-infinite-scroll/vue-infinite-scroll.js");
/* harmony import */ var vue_infinite_scroll__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(vue_infinite_scroll__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _app_vue__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../app.vue */ "./app/javascript/app.vue");
/* harmony import */ var vue_gtag__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! vue-gtag */ "./node_modules/vue-gtag/dist/vue-gtag.esm.js");
/* harmony import */ var vue_google_adsense__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! vue-google-adsense */ "./node_modules/vue-google-adsense/dist/VueGoogleAdsense.esm.min.js");
/* harmony import */ var vue_i18n__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! vue-i18n */ "./node_modules/vue-i18n/dist/vue-i18n.esm.js");
/* harmony import */ var _vue_locales__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../vue/locales */ "./app/javascript/vue/locales/index.js");
/* harmony import */ var vuejs_dialog__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! vuejs-dialog */ "./node_modules/vuejs-dialog/dist/vuejs-dialog.min.js");
/* harmony import */ var vuejs_dialog__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(vuejs_dialog__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var vue_toast_notification__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! vue-toast-notification */ "./node_modules/vue-toast-notification/dist/index.min.js");
/* harmony import */ var vue_toast_notification__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(vue_toast_notification__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var vue_social_sharing__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! vue-social-sharing */ "./node_modules/vue-social-sharing/dist/vue-social-sharing.js");
/* harmony import */ var vue_social_sharing__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(vue_social_sharing__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../util */ "./app/javascript/util/index.js");
/* harmony import */ var vue_lazyload__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! vue-lazyload */ "./node_modules/vue-lazyload/vue-lazyload.esm.js");

global.fetch = node_fetch__WEBPACK_IMPORTED_MODULE_0___default.a;


vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vuex__WEBPACK_IMPORTED_MODULE_2__["default"]);

vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vue_router__WEBPACK_IMPORTED_MODULE_3__["default"]);

vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vue_meta__WEBPACK_IMPORTED_MODULE_4__["default"]);




vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vue_infinite_scroll__WEBPACK_IMPORTED_MODULE_8___default.a);
 // create store and router instances

var store = Object(_vue_store__WEBPACK_IMPORTED_MODULE_5__["createStore"])(); // console.log(store)

var router = Object(_vue_router__WEBPACK_IMPORTED_MODULE_6__["createRouter"])(); // console.log(router)
// sync the router with the vuex store.
// this registers `store.state.route`

var unsync = Object(vuex_router_sync__WEBPACK_IMPORTED_MODULE_7__["sync"])(store, router); // console.log('router')

unsync();
console.log(window.location); // if (window.location.hostname != 'localhost') {


vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vue_gtag__WEBPACK_IMPORTED_MODULE_10__["default"], {
  config: {
    id: "UA-155962082-1"
  }
}, router);

vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(__webpack_require__(/*! vue-script2 */ "./node_modules/vue-script2/dist/vue-script2.js")); // Vue.use(Ads.Adsense)

vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vue_google_adsense__WEBPACK_IMPORTED_MODULE_11__["default"].InArticleAdsense); // Vue.use(Ads.InFeedAdsense)
// }


vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vue_i18n__WEBPACK_IMPORTED_MODULE_12__["default"]);

console.log(Object(_vue_locales__WEBPACK_IMPORTED_MODULE_13__["messages"])());
var i18n = new vue_i18n__WEBPACK_IMPORTED_MODULE_12__["default"]({
  locale: 'fr',
  // set locale
  messages: Object(_vue_locales__WEBPACK_IMPORTED_MODULE_13__["messages"])() // set locale messages

});
 // import VuejsDialogMixin from 'vuejs-dialog/dist/vuejs-dialog-mixin.min.js'; // only needed in custom components
// include the default style
// import 'vuejs-dialog/dist/vuejs-dialog.min.css';
// Tell Vue to install the plugin.

vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vuejs_dialog__WEBPACK_IMPORTED_MODULE_14___default.a);
 // Import one of the available themes
//import 'vue-toast-notification/dist/theme-default.css'
// import 'vue-toast-notification/dist/theme-sugar.css'

vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vue_toast_notification__WEBPACK_IMPORTED_MODULE_15___default.a); // //Vue.$toast.open({/* options */});
// let instance = Vue.$toast.open('You did it!');
// // Force dismiss specific toast
// instance.dismiss();
// // Dismiss all opened toast immediately
// Vue.$toast.clear();


vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vue_social_sharing__WEBPACK_IMPORTED_MODULE_16___default.a);
 // register global utility utils.

Object.keys(_util__WEBPACK_IMPORTED_MODULE_17__).forEach(function (key) {
  vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].filter(key, _util__WEBPACK_IMPORTED_MODULE_17__[key]);
});

vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"].use(vue_lazyload__WEBPACK_IMPORTED_MODULE_18__["default"]); // Vue.filter('truncate', truncate)

document.addEventListener('DOMContentLoaded', function () {
  var app = new vue_dist_vue_esm__WEBPACK_IMPORTED_MODULE_1__["default"]({
    el: '#app',
    i18n: i18n,
    store: store,
    router: router,
    // template: '<App/>',
    // components: {
    //   App,
    //   // MarkdownItVue
    // }
    render: function render(h) {
      return h(_app_vue__WEBPACK_IMPORTED_MODULE_9__["default"]);
    }
  });
  console.log('app'); // document.querySelector('#preload').remove()
});
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/webpack/buildin/global.js */ "./node_modules/webpack/buildin/global.js")))

/***/ }),

/***/ "./app/javascript/util/index.js":
/*!**************************************!*\
  !*** ./app/javascript/util/index.js ***!
  \**************************************/
/*! exports provided: origin, truncateText, hashtagMD, filterDate, sortItemsDesc, host, humanTime, userCreatedAt, shortenNumber, timeAgo, comments, truncate */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "origin", function() { return origin; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "truncateText", function() { return truncateText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hashtagMD", function() { return hashtagMD; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "filterDate", function() { return filterDate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sortItemsDesc", function() { return sortItemsDesc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "host", function() { return host; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "humanTime", function() { return humanTime; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userCreatedAt", function() { return userCreatedAt; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "shortenNumber", function() { return shortenNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "timeAgo", function() { return timeAgo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "comments", function() { return comments; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "truncate", function() { return truncate; });
var origin = function origin(uri) {
  console.log(uri);
  return uri.match(/^(?:.*:\/\/)?(?:www\.)?([^:\/]*).*$/)[1];
};
var truncateText = function truncateText(text, length, clamp) {
  // length = length || 150;
  clamp = clamp || '...';
  var node = document.createElement('div');
  node.innerHTML = text;
  var content = node.textContent; // return content.length > length ? content.slice(0, length) + clamp : content;

  if (/^(.+)(?:[\s,])/.test(content)) {
    return content.length > length ? content.slice(0, length).match(/^(.+)(?:[\s,])/)[1] + clamp : content;
  } else {
    return text;
  }
};
var hashtagMD = function hashtagMD(text) {
  // "[#{word}](/hashtag/#{word.gsub('#', '')})"
  var str = [];
  text.split(' ').forEach(function (word) {
    if (/^#.+|.*\n#.+/.test(word)) {
      if (/^\n#.+/.test(word)) {
        // console.log(word)
        str.push('\n');
        word = word.replace('\n', '');
      }

      if (/.*\n#.+/.test(word)) {
        // console.log(word)
        var temp = word.split('#');
        str.push(temp[0]);
        word = "#".concat(temp[1]);
      } // console.log(word)


      if (/(?:\.$)/.test(word)) str.push("[".concat(word.replace('.', ''), "](/hashtag/").concat(word.replace('.', '').replace('#', ''), ")."));else if (/(?:,$)/.test(word)) str.push("[".concat(word.replace(',', ''), "](/hashtag/").concat(word.replace(',', '').replace('#', ''), "),"));else str.push("[".concat(word, "](/hashtag/").concat(word.replace('#', ''), ")"));
    } else str.push(word);
  }); // console.log(str.join(' '))

  return str.join(' '); // return this.item.content
};
var filterDate = function filterDate(timestamp) {
  var d = new Date();
  var date = d.setDate(d.getDate() - timestamp); // console.log(new Date(date))

  return date;
};
var sortItemsDesc = function sortItemsDesc(items) {
  // console.log(items)
  return items.sort(function (a, b) {
    return a.timestamp > b.timestamp ? 1 : -1;
  }).reverse();
};
var host = function host(url) {
  var host = url.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  var parts = host.split('.').slice(-3);
  if (parts[0] === 'www') parts.shift();
  return parts.join('.');
};
var humanTime = function humanTime(timestamp) {
  return new Date(timestamp);
};
var userCreatedAt = function userCreatedAt(timestamp) {
  // console.log(timestamp)
  if (!timestamp) return null;
  var date = new Date(timestamp);
  var year = new Intl.DateTimeFormat('fr', {
    year: 'numeric'
  }).format(date);
  var month = new Intl.DateTimeFormat('fr', {
    month: 'long'
  }).format(date);
  var day = new Intl.DateTimeFormat('fr', {
    day: '2-digit'
  }).format(date);
  return "".concat(month, " ").concat(year);
};

var round = function round(value, precision) {
  var multiplier = Math.pow(10, precision || 0);
  return Math.round(value * multiplier) / multiplier;
};

var strWithSpaces = function strWithSpaces(str) {
  return str.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
};

var shortenNumber = function shortenNumber(number) {
  // number += 1231
  // number += 10099
  // number += 12345.6789
  // number += 123456789.01
  // console.log(number)
  if (number >= 1000000) return "".concat(strWithSpaces(round(number / 1000000, 1)), " M");
  if (number >= 10000) return "".concat(strWithSpaces(round(number / 1000, 1)), " k");else return strWithSpaces(number);
};
var timeAgo = function timeAgo(time) {
  var between = (Date.now() - Number(time)) / 1000;

  if (between < 3600) {
    return 'il y a ' + pluralize(~~(between / 60), ' minute');
  } else if (between < 86400) {
    return 'il y a ' + pluralize(~~(between / 3600), ' heure');
  } else {
    return 'il y a ' + pluralize(~~(between / 86400), ' jour');
  }
};

var pluralize = function pluralize(time, label) {
  if (time === 1) {
    return time + label;
  }

  return time + label + 's';
};

var comments = function comments(count) {
  return pluralize(count, ' commentaire');
};
var truncate = function truncate(text, length, clamp) {
  length = length || 150;
  clamp = clamp || '...';
  var node = document.createElement('div');
  node.innerHTML = text;
  var content = node.textContent; // return content.length > length ? content.slice(0, length) + clamp : content;

  return content.length > length ? content.slice(0, length).match(/^(.+)(?:[\s,])/)[1] + clamp : content;
};

/***/ }),

/***/ "./app/javascript/vue/api/index.js":
/*!*****************************************!*\
  !*** ./app/javascript/vue/api/index.js ***!
  \*****************************************/
/*! exports provided: commentLike, commentUnlike, commentDelete, replyLike, replyUnlike, replyEdit, replyDelete, replyNew, commentEdit, commentNew, bookmark, unbookmark, follow, unfollow, like, unlike, followers, recipe, users, recipeEdit, recipeNew, recipes, recipeLog, confirmRegistration, signUp, login, logout, search, fetchState, isAuthenticated */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "commentLike", function() { return commentLike; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "commentUnlike", function() { return commentUnlike; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "commentDelete", function() { return commentDelete; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "replyLike", function() { return replyLike; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "replyUnlike", function() { return replyUnlike; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "replyEdit", function() { return replyEdit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "replyDelete", function() { return replyDelete; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "replyNew", function() { return replyNew; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "commentEdit", function() { return commentEdit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "commentNew", function() { return commentNew; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "bookmark", function() { return bookmark; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unbookmark", function() { return unbookmark; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "follow", function() { return follow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unfollow", function() { return unfollow; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "like", function() { return like; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "unlike", function() { return unlike; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "followers", function() { return followers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recipe", function() { return recipe; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "users", function() { return users; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recipeEdit", function() { return recipeEdit; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recipeNew", function() { return recipeNew; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recipes", function() { return recipes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recipeLog", function() { return recipeLog; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "confirmRegistration", function() { return confirmRegistration; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "signUp", function() { return signUp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "login", function() { return login; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "logout", function() { return logout; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "search", function() { return search; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fetchState", function() { return fetchState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isAuthenticated", function() { return isAuthenticated; });
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


function _objectDestructuringEmpty(obj) { if (obj == null) throw new TypeError("Cannot destructure undefined"); }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

 // import Unsplash, { toJson } from 'unsplash-js';
// const logRequests = !!process.env.DEBUG_API
// // console.log(logRequests)
// const api = (child, options) => {
//   logRequests && console.log(`fetching ${child}...`)
//   return axios.create({
//     baseURL: child,
//     timeout: 1000,
//   });
// }
// const fetch = (URI, options) => {
//   return Promise.resolve(api(URI, options))
//     .then(response => response.get())
//     .then(result => {
//       return result;
//     })
//     .catch(ex => {
//       console.log('parsing failed', ex);
//     });
// }
// export const fetchItem = (URI, item) => {
//   return fetch(URI)
// }
// const metaCsrf = document.querySelector("meta[name='csrf-token']")
// const context.getters.csrfToken = metaCsrf.getAttribute('content')
// const domain = 'https://www.cuisinierrebelle.com'

var domain = '';
var commentLike = function commentLike(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/comments/").concat(payload.comment_id, "/likes"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {// comment_id: payload.comment_id,
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var commentUnlike = function commentUnlike(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'delete',
    url: "".concat(domain, "/api/v1/comments/").concat(payload.comment_id, "/likes/0"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {// comment_id: payload.comment_id,
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var commentDelete = function commentDelete(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'delete',
    url: "".concat(domain, "/api/v1/comments/").concat(payload.comment_id),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {// comment_id: payload.comment_id,
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var replyLike = function replyLike(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/comments/").concat(payload.comment_id, "/replies/").concat(payload.reply_id, "/likes"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {// recipe_id: payload.recipe_id,
      // comment_id: payload.comment_id,
      // user_id: payload.user_id,
      // content: payload.content,
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var replyUnlike = function replyUnlike(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'delete',
    url: "".concat(domain, "/api/v1/comments/").concat(payload.comment_id, "/replies/").concat(payload.reply_id, "/likes/0"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {// recipe_id: payload.recipe_id,
      // comment_id: payload.comment_id,
      // user_id: payload.user_id,
      // content: payload.content,
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var replyEdit = function replyEdit(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'patch',
    url: "".concat(domain, "/api/v1/comments/").concat(payload.comment_id, "/replies/").concat(payload.id),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {
      recipe_id: payload.recipe_id,
      comment_id: payload.comment_id,
      user_id: payload.user_id,
      content: payload.content
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var replyDelete = function replyDelete(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'delete',
    url: "".concat(domain, "/api/v1/comments/").concat(payload.comment_id, "/replies/").concat(payload.id),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {// comment_id: payload.comment_id,
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var replyNew = function replyNew(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/comments/").concat(payload.comment_id, "/replies"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {
      recipe_id: payload.recipe_id,
      user_id: payload.user_id,
      comment_id: payload.comment_id,
      content: payload.content // comment: {
      //   recipe_id: payload.recipe_id,
      //   user_id: payload.user_id,
      //   content: payload.content,
      // }

    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var commentEdit = function commentEdit(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'patch',
    url: "".concat(domain, "/api/v1/comments/").concat(payload.id),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {
      recipe_id: payload.recipe_id,
      user_id: payload.user_id,
      content: payload.content // comment: {
      //   recipe_id: payload.recipe_id,
      //   user_id: payload.user_id,
      //   content: payload.content,
      // }

    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var commentNew = function commentNew(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/comments"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {
      recipe_id: payload.recipe_id,
      user_id: payload.user_id,
      content: payload.content // comment: {
      //   recipe_id: payload.recipe_id,
      //   user_id: payload.user_id,
      //   content: payload.content,
      // }

    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var bookmark = function bookmark(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/bookmarks"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {
      recipe_id: payload.recipe_id,
      user_id: payload.user_id,
      bookmark: {
        recipe_id: payload.recipe_id,
        user_id: payload.user_id
      }
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var unbookmark = function unbookmark(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'delete',
    url: "".concat(domain, "/api/v1/bookmarks/").concat(payload.recipe_id),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {}
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var follow = function follow(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/users/").concat(payload.user, "/follow"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    params: {
      user_slug: payload.user
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var unfollow = function unfollow(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/users/").concat(payload.user, "/unfollow"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    params: {
      user_slug: payload.user
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var like = function like(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/likes"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {
      recipe_id: payload.recipe_id,
      user_id: payload.user_id,
      like: {
        recipe_id: payload.recipe_id,
        user_id: payload.user_id
      }
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var unlike = function unlike(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'delete',
    url: "".concat(domain, "/api/v1/likes/").concat(payload.recipe_id),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization)
    },
    data: {}
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var followers = function followers(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'get',
    url: "".concat(domain, "/api/v1/users/").concat(payload, "/followers")
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var recipe = function recipe(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'get',
    url: "".concat(domain, "/api/v1/recipes/").concat(payload)
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var users = function users(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'get',
    url: "".concat(domain, "/api/v1/users")
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var recipeEdit = function recipeEdit(context, payload) {
  console.log(payload);

  var FormData = __webpack_require__(/*! form-data */ "./node_modules/form-data/lib/browser.js");

  var formData = new FormData();
  formData.append('title', payload.title);
  formData.append('subtitle', payload.subtitle);
  formData.append('video', payload.video);
  formData.append('direction', payload.direction);
  formData.append('description', payload.description);
  formData.append('photo', payload.photo);
  formData.append('tag_list', payload.tagList);
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'patch',
    url: "".concat(domain, "/api/v1/recipes/").concat(payload.id),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization),
      'Content-Type': 'multipart/form-data'
    },
    data: formData
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var recipeNew = function recipeNew(context, payload) {
  console.log(payload);

  var FormData = __webpack_require__(/*! form-data */ "./node_modules/form-data/lib/browser.js");

  var formData = new FormData();
  formData.append('title', payload.title);
  formData.append('subtitle', payload.subtitle);
  formData.append('video', payload.video);
  formData.append('direction', payload.direction);
  formData.append('description', payload.description);
  formData.append('photo', payload.photo);
  formData.append('tag_list', payload.tagList);
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/recipes"),
    headers: {
      'Authorization': "Bearer ".concat(context.state.data.authorization),
      'Content-Type': 'multipart/form-data'
    },
    data: formData
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var recipes = function recipes(context, payload) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'get',
    url: "".concat(domain, "/api/v1/recipes")
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var recipeLog = function recipeLog(context, payload) {
  console.log(context); // console.log($('meta[name="csrf-token"]').attr('content'))

  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/recipe_logs"),
    headers: {
      'X-CSRF-Token': context.getters.csrfToken // 'X-User-Email': context.getters.currentUser ? context.getters.currentUser.email : null,
      // 'X-User-Token': context.getters.currentUser ? context.getters.currentUser.authentication_token : null

    },
    data: {
      recipe_id: payload.recipe.id,
      user_id: context.getters.currentUser ? context.getters.currentUser.id : null,
      recipe_log: {
        recipe_id: payload.recipe.id,
        user_id: context.getters.currentUser ? context.getters.currentUser.id : null
      }
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var confirmRegistration = function confirmRegistration(context, payload) {
  // console.log(`${domain}/api/v1/search`)
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    method: 'get',
    url: "".concat(domain, "/api/v1/users/confirmation"),
    headers: {
      'X-CSRF-Token': context.getters.csrfToken
    },
    params: {
      confirmation_token: payload.token
    }
  })["catch"](function (error) {
    console.log(error.response);
  });
};
var signUp = function signUp(context, user) {
  console.log(user); // console.log($('meta[name="csrf-token"]').attr('content'))

  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/users"),
    headers: {
      'X-CSRF-Token': context.getters.csrfToken // 'Accept-Encoding': 'gzip',

    },
    data: {
      "user": {
        "first_name": user.firstName,
        "last_name": user.lastName,
        "email": user.email,
        "password": user.password,
        "password_confirmation": user.confirmation
      }
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var login = function login(context, user) {
  // console.log(user)
  // console.log($('meta[name="csrf-token"]').attr('content'))
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    validateStatus: function validateStatus(status) {
      console.log(status);
      return status < 500; // Resolve only if the status code is less than 500
    },
    method: 'post',
    url: "".concat(domain, "/api/v1/users/sign_in"),
    headers: {
      'X-CSRF-Token': context.getters.csrfToken // 'Accept-Encoding': 'gzip',

    },
    data: {
      user: {
        email: user.email,
        password: user.password
      }
    }
  })["catch"](function (error) {
    console.log(error.toJSON());
    return error;
  });
};
var logout = function logout(context, user) {
  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    method: 'delete',
    url: "".concat(domain, "/api/v1/users/sign_out"),
    headers: {
      'X-CSRF-Token': context.getters.csrfToken,
      // 'X-User-Email': context.getters.currentUser.email,
      // 'X-User-Token': context.getters.currentUser.authentication_token
      'Authorization': "Bearer ".concat(context.state.data.authorization) // 'Accept-Encoding': 'gzip',

    },
    data: {// email: context.getters.currentUser.email,
      // authentication_token: context.getters.currentUser.authentication_token
    }
  })["catch"](function (error) {
    console.log(error.response);
  });
}; // const unsplash = new Unsplash({ accessKey: 'nHSH2XMCvdAgrKbLMHs1M1u7vWUW8vxEmyHvDsTOLTs' });
// export const fetchBannerPicture = (query) => {
//   return unsplash.photos.getRandomPhoto({
//     query: query
//   })
//   .then(toJson)
//   .catch(error => {
//     console.log(error.response)
//   })
// }

var search = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(context, payload) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return axios__WEBPACK_IMPORTED_MODULE_1___default()({
              method: 'get',
              url: "".concat(domain, "/api/v1/search"),
              params: {
                query: payload.query
              }
            })["catch"](function (error) {
              console.log(error.response);
            });

          case 2:
            return _context.abrupt("return", _context.sent);

          case 3:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));

  return function search(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
var fetchState = /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2(context, _ref2) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _objectDestructuringEmpty(_ref2);

            console.log("".concat(domain, "/api/v1/state"));
            _context2.next = 4;
            return axios__WEBPACK_IMPORTED_MODULE_1___default()({
              method: 'get',
              url: "".concat(domain, "/api/v1/state"),
              headers: {// 'Accept-Encoding': 'gzip',
              }
            })["catch"](function (error) {
              console.log(error.response);
            });

          case 4:
            return _context2.abrupt("return", _context2.sent);

          case 5:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));

  return function fetchState(_x3, _x4) {
    return _ref3.apply(this, arguments);
  };
}();
var isAuthenticated = function isAuthenticated(context, user) {
  // console.log(`isAuthenticated? ${context.getters.currentUser.email}`)
  // console.log(context.getters.currentUser.email)
  // console.log( context.getters.currentUser.authentication_token)
  var token = context.state.data.authorization; // console.log(token)

  return axios__WEBPACK_IMPORTED_MODULE_1___default()({
    method: 'get',
    url: "".concat(domain, "/api/v1/state"),
    headers: {
      'Authorization': token != null ? "Bearer ".concat(token) : null // 'Accept-Encoding': 'gzip',

    },
    params: {
      query: 'isAuthenticated' // email: context.getters.currentUser.email,
      // authentication_token: context.getters.currentUser.authentication_token

    }
  })["catch"](function (error) {
    console.log(error.response);
  });
}; // export const follow = (context, { id, type }) => {
//   return axios({
//     method: 'post',
//     url: `/api/v1/user/${id}/${type}`,
//     headers: {
//       'X-User-Email': context.getters.currentUser.email,
//       'X-User-Token': context.getters.currentUser.token
//     },
//     data: {
//       id: id,
//       type: type
//     }
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const liked = (context, { id }) => {
//   return axios({
//     method: 'post',
//     url: `/api/v1/points`,
//     headers: {
//       'X-User-Email': context.getters.currentUser.email,
//       'X-User-Token': context.getters.currentUser.token
//     },
//     data: {
//       post_id: id
//     }
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const pin = (context, { id }) => {
//   return axios({
//     method: 'patch',
//     url: `/api/v1/pin/${id}`,
//     headers: {
//       'X-User-Email': context.getters.currentUser.email,
//       'X-User-Token': context.getters.currentUser.token
//     },
//     data: {
//       id: id
//     }
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const fetchSearchQuery = (context, { query }) => {
//   console.log(query)
//   return axios({
//     method: 'get',
//     url: `/api/v1/search?query=${query}`
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const fetchUserPosts = (context, { user }) => {
//   return axios({
//     method: 'get',
//     url: `/api/v1/user/${user}`
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const fetchPosts = (context, {}) => {
//   return axios({
//     method: 'get',
//     url: `/api/v1/status`
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const fetchPages = (context, {}) => {
//   return axios({
//     method: 'get',
//     url: `/api/v1/pages`
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const addNewComment = (context, { ancestry, post }) => {
//   const url = ancestry !== null ? `/api/v1/comments/${ancestry.id}/reply` : '/api/v1/comments'
//   console.log('context')
//   console.log(context)
//   return axios({
//     method: 'post',
//     url: url,
//     headers: {
//       'X-User-Email': context.getters.currentUser.email,
//       'X-User-Token': context.getters.currentUser.token
//     },
//     data: {
//       content: post.content,
//       post: context.state.route.params.id
//     }
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const addNewPost = (context, { post }) => {
//   return axios({
//     method: 'post',
//     url: '/api/v1/status',
//     headers: {
//       'X-User-Email': context.getters.currentUser.email,
//       'X-User-Token': context.getters.currentUser.token
//     },
//     data: {
//       content: post.content,
//       // post: context.state.route.params.id
//     }
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const forwardPost = (context, { post }) => {
//   return axios({
//     method: 'post',
//     url: `/api/v1/status/${post.id}/forward`,
//     headers: {
//       'X-User-Email': context.getters.currentUser.email,
//       'X-User-Token': context.getters.currentUser.token
//     },
//     data: {
//       content: post.id,
//       // post: context.state.route.params.id
//     }
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const editPost = (context, { post }) => {
//   return axios({
//     method: 'patch',
//     url: `/api/v1/status/${post.id}`,
//     headers: {
//       'X-User-Email': context.getters.currentUser.email,
//       'X-User-Token': context.getters.currentUser.token
//     },
//     data: {
//       content: post.content,
//       // post: context.state.route.params.id
//     }
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const deletePost = (context, { id }) => {
//   return axios({
//     method: 'delete',
//     url: `/api/v1/status/${id}`,
//     headers: {
//       'X-User-Email': context.getters.currentUser.email,
//       'X-User-Token': context.getters.currentUser.token
//     },
//     // data: {
//     //   // content: post.content,
//     //   // post: context.state.route.params.id
//     // }
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }
// export const deleteComment = (context, { id }) => {
//   return axios({
//     method: 'delete',
//     url: `/api/v1/comments/${id}`,
//     headers: {
//       'X-User-Email': context.getters.currentUser.email,
//       'X-User-Token': context.getters.currentUser.token
//     },
//     // data: {
//     //   // content: post.content,
//     //   // post: context.state.route.params.id
//     // }
//   })
//   .catch(error => {
//     console.log(error.response)
//   })
// }

/***/ }),

/***/ "./app/javascript/vue/locales/fr.js":
/*!******************************************!*\
  !*** ./app/javascript/vue/locales/fr.js ***!
  \******************************************/
/*! exports provided: fr */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "fr", function() { return fr; });
function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var fr = function fr() {
  var _ref;

  console.log('french');
  return _ref = {
    init: {
      loading: 'Chargement...'
    },
    error: {
      failed: 'Nous sommes désolés, nous ne sommes pas en mesure de récupérer ces informations pour le moment, veuillez réessayer plus tard'
    },
    comment: {
      "delete": 'Supprimer'
    },
    commentForm: {
      comment: "Commenter",
      reply: 'Répondre'
    },
    follow: {
      edit: 'Éditer',
      follow: 'Suivre',
      unfollow: 'Se désabonner',
      followed: 'Abonné',
      following: '',
      followers: ''
    },
    message: {
      hello: 'bonjour le monde'
    },
    hashtag: {
      publications: 'Publications'
    },
    item: {
      edit: 'Éditer',
      "delete": 'Supprimer',
      delete_q: "Voulez-vous supprimer cette publication ?",
      post: 'Publier',
      pin: 'Épingler',
      pin_q: "Voulez-vous épingler cette publication ?",
      unpin: 'Détacher',
      unpin_q: "Voulez-vous détacher cette publication ?",
      copy_to_clipboard: "Copier le lien",
      copy_success: 'Lien copié',
      share: 'Partager cette publication',
      share_btn: 'Partager',
      forward: 'Transférer',
      deleted: 'Cette publication a été supprimée.'
    },
    itemNewForm: {
      cancel: 'Annuler',
      cancel_q: "Voulez-vous annuler cette publication ?",
      post: 'Publier',
      whats_happening: "Que se passe-t-il ?"
    },
    user: {
      publications: 'Publications'
    },
    pages: {
      edit: 'Editer'
    },
    posts: {
      publications: 'Publications'
    },
    post: {
      answer: 'Répondre',
      add_comment: 'Ajouter un commentaire'
    },
    filter: {
      title: "Filtrer p\xE9riode",
      today: "Aujourd'hui",
      day: "24 heures",
      week: "7 jours",
      month: "30 jours",
      all: "Depuis le d\xE9but"
    },
    navbar: {
      brand: 'Cuisinier Rebelle',
      cancel: 'Annuler',
      logout: 'Se déconnecter',
      login: 'Se connecter',
      getStarted: "Cr\xE9er un compte",
      // admin_html: <i class="material-icons md-18">settings</i>
      are_you_sure: 'Êtes-vous sûr ?',
      // bookmarks_html: <i class="material-icons md-18">bookmarks</i>
      conversion: 'Table de conversion',
      cuisinier_rebelle: 'Cuisinier rebelle',
      english_html: 'English',
      following: 'Mes abonnements',
      french_html: 'Français',
      inbox: 'Messages',
      // languages_html: <i class="material-icons md-18">language</i>
      log_out: 'Se déconnecter',
      // menu_modal_html: <i class="material-icons md-18">more_vert</i>
      new_recipe: 'Nouvelle recette',
      // notifications_html: <i class="material-icons md-18">notifications</i>
      recipes: 'Mes recettes',
      settings: 'Paramètres',
      sign_in: 'Se connecter',
      spanish_html: 'Español',
      tools: 'Matériel de cuisine',
      top_100: 'Top 100',
      bookmarks: 'Mes favoris',
      search: 'Rechercher' // top_100_html: <i class="material-icons md-18">whatshot</i>

    },
    login: {
      email: 'Adresse Courriel',
      password: 'Mot de passe',
      submit: 'Se connecter',
      signup: "Cr\xE9er un compte",
      disclaimer: "Nous ne partagerons jamais vos données personnelles.",
      welcome: 'Bienvenue, {firstName} !'
    },
    signUp: {
      confirmation: 'Confirmation du mot de passe',
      disclaimer: "Nous ne partagerons jamais vos données personnelles.",
      email: 'Adresse Courriel',
      firstName: 'Prénom',
      lastName: 'Nom de famille',
      login: 'Se connecter',
      password: 'Mot de passe',
      signup: "S'inscrire",
      submit: "S'inscrire",
      success: 'Vous allez recevoir sous quelques minutes un courriel comportant des instructions pour confirmer votre compte.',
      errors: {
        email: "L'adresse courriel est obligatoire.",
        emailFormat: "Ceci n'est pas une adresse courriel.",
        firstName: 'Le prénom est obligatoire.',
        lastName: 'Le nom de famille est obligatoire.',
        password: 'Le mot de passe est obligatoire.',
        confirmation: 'Le mot de passe saisi ne correspond pas à la confirmation.',
        passwordLength: 'Veuillez saisir au moins 8 caractères.'
      }
    },
    banner: {
      login: 'Se connecter',
      getStarted: "Cr\xE9er un compte",
      introduction: 'Partagez vos recettes dès maintenant<br/>en toute simplicité',
      seeRecipes: 'Voir les recettes'
    },
    userBanner: {
      followers: '0 Abonnés | 1 Abonné | {count} Abonnés' // apple: 'no apples | one apple | {count} apples',

    },
    recipe: {
      edit: 'Éditer cette recette',
      otherRecipes: 'Autres recettes',
      comments: {
        counts: '0 Commentaires | 1 Commentaire | {count} Commentaires',
        addPublicComment: 'Ajouter un commentaire public...',
        viewReplies: 'Voir 0 réponses | Voir la réponse | Voir les {count} réponses'
      },
      "new": {
        title: 'Titre',
        subtitle: 'Sous-titre',
        video: 'Adresse vidéo YouTube',
        direction: 'Contenu de publication',
        tags: 'Tags',
        tagsHelp: 'Séparer chaque tag par une virgule.',
        browse: 'Ajouter une photo',
        chooseFile: 'Chercher',
        photo: 'Photo',
        submit: 'Publier',
        description: 'Description',
        descriptionHelp: '{count} caractères restant.',
        errors: {
          youtubeVideoUrl: 'Le lien doit être un lien YouTube.',
          title: 'Le titre est obligatoire.',
          direction: 'Le contenu de publication est obligatoire.',
          photo: 'La photo est obligatoire.'
        }
      }
    }
  }, _defineProperty(_ref, "comment", {
    minutes: 'il y a 0 minutes | il y a 1 minute | il y a {count} minutes',
    hours: 'il y a 0 heures | il y a 1 heure | il y a {count} heures',
    days: 'il y a 0 jours | il y a 1 jour | il y a {count} jours',
    months: 'il y a 0 mois | il y a 1 mois | il y a {count} mois',
    years: 'il y a 0 ans | il y a 1 an | il y a {count} ans'
  }), _defineProperty(_ref, "commentForm", {
    comment: 'Publier',
    cancel: 'Annuler'
  }), _defineProperty(_ref, "search", {
    noResult: "D\xE9sol\xE9, nous n'avons trouv\xE9 aucun r\xE9sultat correspondant \xE0 <em>\"{query}\"</em>. Veuillez essayer de nouveau avec un autre mot-cl\xE9."
  }), _defineProperty(_ref, "follow", {
    followers: '0 Abonnés | 1 Abonné | {count} Abonnés',
    following: '0 Abonnements | 1 Abonnement | {count} Abonnements',
    follow: "S'abonner",
    unfollow: "Se d\xE9sabonner"
  }), _defineProperty(_ref, "RegistrationConfirmation", {
    success: '{firstName}, votre compte est maintenant actif.'
  }), _ref;
};

/***/ }),

/***/ "./app/javascript/vue/locales/index.js":
/*!*********************************************!*\
  !*** ./app/javascript/vue/locales/index.js ***!
  \*********************************************/
/*! exports provided: messages */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "messages", function() { return messages; });
/* harmony import */ var _locales_fr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../locales/fr */ "./app/javascript/vue/locales/fr.js");

var messages = function messages() {
  console.log('messages');
  return {
    // en: {
    //   message: {
    //     hello: 'hello world'
    //   }
    // },
    // ja: {
    //   message: {
    //     hello: 'こんにちは、世界'
    //   }
    // }
    fr: Object(_locales_fr__WEBPACK_IMPORTED_MODULE_0__["fr"])()
  };
};

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/app.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/app.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobile_device_detect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mobile-device-detect */ "./node_modules/mobile-device-detect/dist/index.js");
/* harmony import */ var mobile_device_detect__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mobile_device_detect__WEBPACK_IMPORTED_MODULE_1__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

//
//
//
//
//
//
//
//
//
//
 // import Navbar from './vue/components/Navbar.vue'
// import Footer from './vue/components/Footer.vue'

var Navbar = function Navbar() {
  return __webpack_require__.e(/*! import() */ 29).then(__webpack_require__.bind(null, /*! ./vue/components/Navbar.vue */ "./app/javascript/vue/components/Navbar.vue"));
};

var Footer = function Footer() {
  return __webpack_require__.e(/*! import() */ 28).then(__webpack_require__.bind(null, /*! ./vue/components/Footer.vue */ "./app/javascript/vue/components/Footer.vue"));
};

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'app',
  data: function data() {
    return {
      loading: true
    };
  },
  metaInfo: {
    // if no subcomponents specify a metaInfo.title, this title will be used
    title: 'Cuisinier Rebelle',
    // all titles will be injected into this template
    titleTemplate: '%s | Cuisinier Rebelle',
    meta: [{
      vmid: 'description',
      name: 'description',
      content: 'Partagez vos recettes dès maintenant en toute simplicité'
    }, {
      vmid: 'fb:app_id',
      property: 'fb:app_id',
      content: '570259036897585'
    }, {
      vmid: 'og:site_name',
      property: 'og:site_name',
      content: 'Cuisinier Rebelle'
    }, {
      vmid: 'og:title',
      property: 'og:title',
      content: 'Cuisinier Rebelle'
    }, {
      vmid: 'og:description',
      property: 'og:description',
      content: 'Partagez vos recettes dès maintenant en toute simplicité'
    }, {
      vmid: 'og:locale',
      property: 'og:locale',
      content: 'fr_FR'
    }, {
      vmid: 'og:type',
      property: 'og:type',
      content: 'website'
    }, {
      vmid: 'og:url',
      property: 'og:url',
      content: "https://www.cuisinierrebelle.com/"
    }, {
      vmid: 'og:image',
      property: 'og:image',
      content: 'https://media.cuisinierrebelle.com/images/cr_icon_1200x1200.jpg'
    }, {
      vmid: 'twitter:card',
      name: 'twitter:card',
      content: 'summary_large_image'
    }, {
      vmid: 'twitter:site',
      name: 'twitter:site',
      content: '@cuisinierrebelle'
    }, {
      vmid: 'twitter:creator',
      name: 'twitter:creator',
      content: '@cuisinierrebelle'
    }, {
      vmid: 'twitter:title',
      name: 'twitter:title',
      content: 'Cuisinier Rebelle'
    }, {
      vmid: 'twitter:description',
      name: 'twitter:description',
      content: 'Partagez vos recettes dès maintenant en toute simplicité'
    }, {
      vmid: 'twitter:image',
      name: 'twitter:image',
      content: 'https://media.cuisinierrebelle.com/images/cr_icon_1200x1200.jpg'
    }]
  },
  components: {
    'app-footer': Footer,
    'app-header': Navbar
  },
  methods: {
    checkAuthentication: function checkAuthentication() {
      var _this = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _this.$store.dispatch('IS_AUTHENTICATED', {}).then(function (result) {
                  return console.log(result);
                });

              case 2:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    fetchItems: function fetchItems() {
      var _this2 = this;

      this.loading = true;
      console.log('SET_STORE');
      this.$store.dispatch('SET_STORE', {}).then(function (response) {
        console.log(response); // this.filter = this.$store.getters.posts
        // this.posts = this.$store.getters.posts
      })["finally"](function () {
        _this2.loading = false;
      });
    }
  },
  computed: {
    // user () {
    //   return this.$store.getters.currentUser
    // },
    // items () {
    //   return this.filter
    // },
    timestamp: function timestamp() {
      // if (this.$store.state.data.timestamp === null) this.fetchItems()
      return this.$store.state.data.timestamp;
    },
    mobile: function mobile() {
      return mobile_device_detect__WEBPACK_IMPORTED_MODULE_1__["isMobile"];
    }
  },
  beforeMount: function beforeMount() {
    var _this3 = this;

    return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return _this3.checkAuthentication();

            case 2:
              _this3.fetchItems();

            case 3:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }))();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/app.vue?vue&type=template&id=6fb8108a&":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/app.vue?vue&type=template&id=6fb8108a& ***!
  \*********************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "app" } },
    [
      _c("app-header"),
      _vm._v(" "),
      _c("main", [_c("router-view")], 1),
      _vm._v(" "),
      _c("app-footer")
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=hello_vue~._app_javascript_a-fa17d73cf4b3b9576b31.chunk.js.map