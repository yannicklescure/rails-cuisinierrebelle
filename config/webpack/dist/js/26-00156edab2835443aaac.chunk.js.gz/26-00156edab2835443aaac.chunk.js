(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[26],{

/***/ "./app/javascript/vue/components/Banner.vue":
/*!**************************************************!*\
  !*** ./app/javascript/vue/components/Banner.vue ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Banner_vue_vue_type_template_id_6e2a67b6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Banner.vue?vue&type=template&id=6e2a67b6& */ "./app/javascript/vue/components/Banner.vue?vue&type=template&id=6e2a67b6&");
/* harmony import */ var _Banner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Banner.vue?vue&type=script&lang=js& */ "./app/javascript/vue/components/Banner.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Banner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Banner_vue_vue_type_template_id_6e2a67b6___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Banner_vue_vue_type_template_id_6e2a67b6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/components/Banner.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/components/Banner.vue?vue&type=script&lang=js&":
/*!***************************************************************************!*\
  !*** ./app/javascript/vue/components/Banner.vue?vue&type=script&lang=js& ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--6-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Banner.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/Banner.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/components/Banner.vue?vue&type=template&id=6e2a67b6&":
/*!*********************************************************************************!*\
  !*** ./app/javascript/vue/components/Banner.vue?vue&type=template&id=6e2a67b6& ***!
  \*********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_template_id_6e2a67b6___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Banner.vue?vue&type=template&id=6e2a67b6& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/Banner.vue?vue&type=template&id=6e2a67b6&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_template_id_6e2a67b6___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Banner_vue_vue_type_template_id_6e2a67b6___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/Banner.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/Banner.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../api */ "./app/javascript/vue/api/index.js");
/* harmony import */ var unsplash_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! unsplash-js */ "./node_modules/unsplash-js/lib/unsplash.js");
/* harmony import */ var unsplash_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(unsplash_js__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



var unsplash = new unsplash_js__WEBPACK_IMPORTED_MODULE_2___default.a({
  accessKey: 'nHSH2XMCvdAgrKbLMHs1M1u7vWUW8vxEmyHvDsTOLTs'
});
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Banner',
  data: function data() {
    return {
      image: {
        id: null,
        url: null,
        link: {
          download: null
        },
        user: {
          name: null,
          username: null
        }
      }
    };
  },
  methods: {
    getBannerPicture: function getBannerPicture() {
      var _this = this;

      var query = "cooking, food, chef"; // fetchBannerPicture(query)

      unsplash.photos.getRandomPhoto({
        query: query
      }).then(unsplash_js__WEBPACK_IMPORTED_MODULE_2__["toJson"]).then(function (response) {
        console.log(response);
        _this.image = {
          id: response.id,
          url: "".concat(response.urls.raw, "&w=1600&h=900&fm=webp"),
          link: {
            download: response.links.download
          },
          user: {
            name: response.user.name,
            username: response.user.username
          }
        };
      })["catch"](function (error) {
        console.log(error.response);
      });
    },
    imageTrackDownload: function imageTrackDownload() {
      console.log("track download photo id ".concat(this.image.id));
      unsplash.photos.getPhoto(this.image.id).then(unsplash_js__WEBPACK_IMPORTED_MODULE_2__["toJson"]).then(function (json) {
        unsplash.photos.trackDownload(json);
      }); // browser.downloads.download({
      //   url : this.image.link.download,
      //   filename : 'my-image-again.png',
      //   conflictAction : 'uniquify'
      // })
    },
    scrollToCards: function scrollToCards() {
      var element = document.querySelector('#recipes-cards');
      console.log(element);
      var scrollOptions = {
        top: element.offsetTop - this.navbarHeight,
        left: 0,
        behavior: 'smooth'
      };
      window.scrollTo(scrollOptions);
    }
  },
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapGetters"])(['navbarHeight'])),
  beforeMount: function beforeMount() {
    this.getBannerPicture();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/Banner.vue?vue&type=template&id=6e2a67b6&":
/*!***************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/Banner.vue?vue&type=template&id=6e2a67b6& ***!
  \***************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass:
        "banner-background banner-height d-flex justify-content-center justify-content-md-center align-items-center flex-column mb-3",
      style:
        "background-image: linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(" +
        _vm.image.url +
        ")"
    },
    [
      _c(
        "div",
        {
          staticClass:
            "banner-height d-flex flex-column justify-content-between"
        },
        [
          _c(
            "div",
            {
              staticClass:
                "d-flex flex-column flex-grow-1 justify-content-center align-items-center"
            },
            [
              _c("div", { staticClass: "container" }, [
                _c(
                  "div",
                  {
                    staticClass: "text-center",
                    attrs: { id: "banner-cta-box" }
                  },
                  [
                    _c("div", {
                      staticClass: "lead text-white text-center",
                      domProps: {
                        innerHTML: _vm._s(_vm.$t("banner.introduction"))
                      }
                    })
                  ]
                ),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass:
                      "d-flex mt-3 justify-content-center flex-column flex-md-row",
                    attrs: { id: "banner-cta-box-btn" }
                  },
                  [
                    _c(
                      "router-link",
                      {
                        staticClass: "btn btn-warning mt-3 mx-3 mt-md-0",
                        attrs: { to: "/login" }
                      },
                      [_vm._v(_vm._s(_vm.$t("banner.login")))]
                    ),
                    _vm._v(" "),
                    _c(
                      "router-link",
                      {
                        staticClass: "btn btn-info mt-3 mx-3 mt-md-0",
                        attrs: { to: "/signup" }
                      },
                      [_vm._v(_vm._s(_vm.$t("banner.getStarted")))]
                    )
                  ],
                  1
                )
              ]),
              _vm._v(" "),
              _c(
                "div",
                {
                  staticClass: "btn btn-link m-3 text-muted",
                  on: { click: _vm.scrollToCards }
                },
                [_vm._v(_vm._s(_vm.$t("banner.seeRecipes")))]
              )
            ]
          ),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "d-flex justify-content-center text-muted" },
            [
              _c("div", { staticClass: "d-block mb-3" }, [
                _c(
                  "div",
                  {
                    staticClass:
                      "d-flex justify-content-center align-items-center"
                  },
                  [
                    _c("span", { staticClass: "small" }, [_vm._v("Photo by ")]),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "text-light small",
                        attrs: {
                          href:
                            "https://unsplash.com/@" +
                            _vm.image.user.username +
                            "?utm_source=cuisinier_rebelle&utm_medium=referral&utm_campaign=api-credit",
                          target: "_blank"
                        }
                      },
                      [_vm._v(_vm._s(_vm.image.user.name))]
                    ),
                    _vm._v(" "),
                    _c("span", { staticClass: "small" }, [_vm._v(" on ")]),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "text-light small",
                        attrs: {
                          href:
                            "https://unsplash.com/?utm_source=cuisinier_rebelle&utm_medium=referral",
                          target: "_blank"
                        }
                      },
                      [_vm._v("Unsplash")]
                    ),
                    _vm._v(" "),
                    _c(
                      "a",
                      {
                        staticClass: "ml-2 text-light text-decoration-none",
                        attrs: {
                          href: _vm.image.link.download,
                          target: "_blank"
                        },
                        on: { click: _vm.imageTrackDownload }
                      },
                      [
                        _c(
                          "span",
                          { staticClass: "material-icons md-16 d-flex" },
                          [_vm._v("get_app")]
                        )
                      ]
                    )
                  ]
                )
              ])
            ]
          )
        ]
      )
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=26-00156edab2835443aaac.chunk.js.map