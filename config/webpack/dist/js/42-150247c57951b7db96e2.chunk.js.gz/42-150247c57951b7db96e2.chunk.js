(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[42],{

/***/ "./app/javascript/vue/views/Recipe.vue":
/*!*********************************************!*\
  !*** ./app/javascript/vue/views/Recipe.vue ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Recipe_vue_vue_type_template_id_7b7de8ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Recipe.vue?vue&type=template&id=7b7de8ae& */ "./app/javascript/vue/views/Recipe.vue?vue&type=template&id=7b7de8ae&");
/* harmony import */ var _Recipe_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Recipe.vue?vue&type=script&lang=js& */ "./app/javascript/vue/views/Recipe.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Recipe_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Recipe_vue_vue_type_template_id_7b7de8ae___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Recipe_vue_vue_type_template_id_7b7de8ae___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/views/Recipe.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/views/Recipe.vue?vue&type=script&lang=js&":
/*!**********************************************************************!*\
  !*** ./app/javascript/vue/views/Recipe.vue?vue&type=script&lang=js& ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Recipe_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--6-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Recipe.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Recipe.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Recipe_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/views/Recipe.vue?vue&type=template&id=7b7de8ae&":
/*!****************************************************************************!*\
  !*** ./app/javascript/vue/views/Recipe.vue?vue&type=template&id=7b7de8ae& ***!
  \****************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Recipe_vue_vue_type_template_id_7b7de8ae___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Recipe.vue?vue&type=template&id=7b7de8ae& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Recipe.vue?vue&type=template&id=7b7de8ae&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Recipe_vue_vue_type_template_id_7b7de8ae___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Recipe_vue_vue_type_template_id_7b7de8ae___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Recipe.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/views/Recipe.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var mobile_device_detect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mobile-device-detect */ "./node_modules/mobile-device-detect/dist/index.js");
/* harmony import */ var mobile_device_detect__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mobile_device_detect__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var vue_markdown__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-markdown */ "./node_modules/vue-markdown/dist/vue-markdown.common.js");
/* harmony import */ var vue_markdown__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vue_markdown__WEBPACK_IMPORTED_MODULE_3__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

 // import axios from 'axios'

 // import BtnBookmark from '../components/buttons/Bookmark.vue'
// import BtnComment from '../components/buttons/Comment.vue'
// import BtnLike from '../components/buttons/Like.vue'
// import BtnPrint from '../components/buttons/Print.vue'
// import BtnShare from '../components/buttons/Share.vue'
// import BtnVisit from '../components/buttons/Visit.vue'
// import CardSmall from '../components/CardSmall.vue'
// import Comments from '../components/comments/List.vue'

var BtnBookmark = function BtnBookmark() {
  return __webpack_require__.e(/*! import() */ 4).then(__webpack_require__.bind(null, /*! ../components/buttons/Bookmark.vue */ "./app/javascript/vue/components/buttons/Bookmark.vue"));
};

var BtnComment = function BtnComment() {
  return __webpack_require__.e(/*! import() */ 5).then(__webpack_require__.bind(null, /*! ../components/buttons/Comment.vue */ "./app/javascript/vue/components/buttons/Comment.vue"));
};

var BtnLike = function BtnLike() {
  return __webpack_require__.e(/*! import() */ 6).then(__webpack_require__.bind(null, /*! ../components/buttons/Like.vue */ "./app/javascript/vue/components/buttons/Like.vue"));
};

var BtnPrint = function BtnPrint() {
  return __webpack_require__.e(/*! import() */ 32).then(__webpack_require__.bind(null, /*! ../components/buttons/Print.vue */ "./app/javascript/vue/components/buttons/Print.vue"));
};

var BtnShare = function BtnShare() {
  return __webpack_require__.e(/*! import() */ 7).then(__webpack_require__.bind(null, /*! ../components/buttons/Share.vue */ "./app/javascript/vue/components/buttons/Share.vue"));
};

var BtnVisit = function BtnVisit() {
  return __webpack_require__.e(/*! import() */ 8).then(__webpack_require__.bind(null, /*! ../components/buttons/Visit.vue */ "./app/javascript/vue/components/buttons/Visit.vue"));
};

var CardSmall = function CardSmall() {
  return __webpack_require__.e(/*! import() */ 27).then(__webpack_require__.bind(null, /*! ../components/CardSmall.vue */ "./app/javascript/vue/components/CardSmall.vue"));
};

var Comments = function Comments() {
  return __webpack_require__.e(/*! import() */ 35).then(__webpack_require__.bind(null, /*! ../components/comments/List.vue */ "./app/javascript/vue/components/comments/List.vue"));
};

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Recipe',
  data: function data() {
    return {
      componentKey: 0,
      log: true,
      item: {
        comments: [],
        recipe: {
          title: null,
          subtitle: null,
          direction: null,
          description: null,
          photo: {
            full: {
              url: null
            },
            openGraph: {
              url: null
            }
          },
          video: null
        },
        user: {
          image: {
            thumb: {
              url: null
            }
          },
          slug: null,
          name: null,
          checked: null
        }
      },
      loading: false
    };
  },
  metaInfo: function metaInfo() {
    return {
      title: this.title,
      meta: [{
        vmid: 'description',
        name: 'description',
        content: this.item.recipe.description
      }, {
        vmid: 'fb:app_id',
        property: 'fb:app_id',
        content: '570259036897585'
      }, {
        vmid: 'og:site_name',
        property: 'og:site_name',
        content: 'Cuisinier Rebelle'
      }, {
        vmid: 'og:title',
        property: 'og:title',
        content: "".concat(this.item.recipe.title, " | Cuisinier Rebelle")
      }, {
        vmid: 'og:description',
        property: 'og:description',
        content: this.item.recipe.description
      }, {
        vmid: 'og:locale',
        property: 'og:locale',
        content: 'fr_FR'
      }, {
        vmid: 'og:type',
        property: 'og:type',
        content: 'website'
      }, {
        vmid: 'og:url',
        property: 'og:url',
        content: "https://www.cuisinierrebelle.com/r/".concat(this.$route.params.id)
      }, {
        vmid: 'og:image',
        property: 'og:image',
        content: this.item.recipe.photo.openGraph.url
      }, {
        vmid: 'twitter:card',
        name: 'twitter:card',
        content: 'summary_large_image'
      }, {
        vmid: 'twitter:site',
        name: 'twitter:site',
        content: '@cuisinierrebelle'
      }, {
        vmid: 'twitter:creator',
        name: 'twitter:creator',
        content: '@cuisinierrebelle'
      }, {
        vmid: 'twitter:title',
        name: 'twitter:title',
        content: "".concat(this.item.recipe.title, " | Cuisinier Rebelle")
      }, {
        vmid: 'twitter:description',
        name: 'twitter:description',
        content: this.item.recipe.description
      }, {
        vmid: 'twitter:image',
        name: 'twitter:image',
        content: this.item.recipe.photo.openGraph.url
      }]
    };
  },
  components: {
    BtnBookmark: BtnBookmark,
    BtnComment: BtnComment,
    BtnLike: BtnLike,
    BtnPrint: BtnPrint,
    BtnShare: BtnShare,
    BtnVisit: BtnVisit,
    CardSmall: CardSmall,
    Comments: Comments,
    VueMarkdown: vue_markdown__WEBPACK_IMPORTED_MODULE_3___default.a
  },
  computed: _objectSpread(_objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_2__["mapGetters"])(['navbarHeight', 'recipe', 'currentUser'])), {}, {
    // item () {
    //   return this.recipe(this.$route.params.id)
    // },
    mobile: function mobile() {
      return mobile_device_detect__WEBPACK_IMPORTED_MODULE_1__["isMobile"];
    },
    localhost: function localhost() {
      return window.location.hostname === 'localhost';
    }
  }),
  methods: {
    heartFillBig: function heartFillBig() {
      var _this = this;

      console.log('liked');
      this.$refs.heartFillBig.innerHTML = '<i class="material-icons md-96 text-danger">favorite</i>';
      setTimeout(function () {
        _this.$refs.heartFillBig.innerHTML = '';
      }, 1000);
    },
    bookmarkFillBig: function bookmarkFillBig() {
      var _this2 = this;

      console.log('liked');
      this.$refs.bookmarkFillBig.innerHTML = '<i class="material-icons md-96 text-body">bookmark</i>';
      setTimeout(function () {
        _this2.$refs.bookmarkFillBig.innerHTML = '';
      }, 1000);
    },
    lastCommentMounted: function lastCommentMounted(payload) {
      console.log("lastCommentMounted ".concat(payload)); // this.scroll2Anchor(payload)
    },
    scroll2Anchor: function scroll2Anchor() {
      // const currentPage = this.$route.fullpath
      var target = this.$route.hash;

      if (target && target === '#comments') {
        // console.log(this.$route)
        console.log(target); // console.log(target.match(/(?:#)(.+)/)[1])

        var element = this.$el.querySelector(target); // if (target.match(/(?:#)(.+)/)[1] === 'comments') element = this.$refs.comments

        console.log(element);

        if (element) {
          var scrollOptions = {
            top: element.offsetTop - this.navbarHeight,
            left: 0,
            behavior: 'smooth'
          };
          window.scrollTo(scrollOptions);
          window.history.pushState("object or string", "Title", this.$route.path);
        }
      }
    },
    fetchItem: function fetchItem() {
      var _this3 = this;

      console.log('fetching recipe data');
      this.loading = true;
      this.$store.dispatch('RECIPE', this.$route.params.id).then(function (response) {
        console.log(response);
        _this3.item = response.data; // if (this.log) {
        //   this.$store
        //     .dispatch('SET_STORE', {})
        //     .then(() => this.log = false)
        // }

        _this3.componentKey += 1;
        _this3.loading = false;
      })["finally"](function () {
        _this3.scroll2Anchor();
      });
    }
  },
  watch: {
    '$route': function $route() {
      var _this4 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                console.log(_this4.$route.params.id);
                _context.next = 3;
                return _this4.fetchItem();

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    }
  },
  beforeMount: function beforeMount() {
    this.fetchItem();
  },
  mounted: function mounted() {
    this.$nextTick(function () {// this.componentKey += 1
      // this.loading = false
      // this.scroll2Anchor()
      // setTimeout(() => {
      // }, 1000)
    });
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Recipe.vue?vue&type=template&id=7b7de8ae&":
/*!**********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/views/Recipe.vue?vue&type=template&id=7b7de8ae& ***!
  \**********************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { key: _vm.componentKey, style: { paddingTop: _vm.navbarHeight + "px" } },
    [
      _vm.item.recipe.title
        ? _c(
            "div",
            {
              staticClass: "container py-3 mb-5 recipe",
              staticStyle: { height: "auto !important" }
            },
            [
              _c(
                "div",
                {
                  staticClass:
                    "d-flex flex-column flex-md-row justify-content-between"
                },
                [
                  _c(
                    "div",
                    {
                      class: [
                        { "mb-0": _vm.mobile },
                        "d-flex align-items-center order-0"
                      ],
                      attrs: { id: "recipe-user" }
                    },
                    [
                      _c(
                        "div",
                        {
                          staticClass:
                            "d-flex flex-grow-1 m-0 align-items-center"
                        },
                        [
                          _c(
                            "div",
                            {
                              staticClass:
                                "d-flex flex-grow-1 flex-grow-md-0 justify-content-between justify-md-content-start align-items-center"
                            },
                            [
                              _c("img", {
                                directives: [
                                  {
                                    name: "lazy",
                                    rawName: "v-lazy",
                                    value: _vm.item.user.image.thumb.url,
                                    expression: "item.user.image.thumb.url"
                                  }
                                ],
                                staticClass: "rounded-circle mr-2",
                                staticStyle: { "object-fit": "cover" },
                                attrs: { width: "24px", height: "24px" }
                              }),
                              _vm._v(" "),
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "d-flex order-0 justify-content-between justify-content-md-start flex-grow-1 align-items-center",
                                  attrs: { "data-user": "1" }
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "mr-md-2 d-flex align-items-center"
                                    },
                                    [
                                      _c(
                                        "router-link",
                                        {
                                          staticClass:
                                            "text-body text-capitalize",
                                          staticStyle: { "font-size": "90%" },
                                          attrs: {
                                            to: "/u/" + _vm.item.user.slug
                                          }
                                        },
                                        [_vm._v(_vm._s(_vm.item.user.name))]
                                      ),
                                      _vm._v(" "),
                                      _vm.item.user.checked
                                        ? _c(
                                            "span",
                                            {
                                              staticClass: "d-flex ml-1",
                                              attrs: {
                                                "data-toggle": "tooltip",
                                                "data-placement": "top",
                                                title: "Verified"
                                              }
                                            },
                                            [
                                              _c(
                                                "i",
                                                {
                                                  staticClass:
                                                    "material-icons md-16"
                                                },
                                                [_vm._v("check_circle")]
                                              )
                                            ]
                                          )
                                        : _vm._e()
                                    ],
                                    1
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "d-none mr-3 btn btn-dark btn-sm py-0"
                                    },
                                    [_vm._v("Follow")]
                                  )
                                ]
                              )
                            ]
                          )
                        ]
                      )
                    ]
                  ),
                  _vm._v(" "),
                  !_vm.mobile && _vm.item.user.id === _vm.currentUser.id
                    ? _c(
                        "div",
                        [
                          _c(
                            "router-link",
                            {
                              staticClass:
                                "text-body text-capitalize text-decoration-none",
                              attrs: {
                                to: "/r/" + _vm.item.recipe.slug + "/edit"
                              }
                            },
                            [_vm._v(_vm._s(_vm.$t("recipe.edit")))]
                          )
                        ],
                        1
                      )
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.mobile
                    ? _c("div", { staticClass: "py-2" }, [
                        _c(
                          "div",
                          {
                            staticClass:
                              "recipe-image d-flex justify-content-center align-items-center",
                            style: {
                              backgroundImage:
                                "url(" + _vm.item.recipe.photo.card.url + ")"
                            }
                          },
                          [
                            _c("div", { ref: "heartFillBig" }),
                            _vm._v(" "),
                            _c("div", { ref: "bookmarkFillBig" })
                          ]
                        )
                      ])
                    : _vm._e(),
                  _vm._v(" "),
                  _vm.mobile
                    ? _c(
                        "div",
                        {
                          staticClass:
                            "d-flex order-0 align-items-center justify-content-between mb-3 mb-md-0 d-print-none"
                        },
                        [
                          _c(
                            "div",
                            { staticClass: "d-flex order-0 align-items-start" },
                            [
                              _c("btn-like", {
                                attrs: { item: _vm.item },
                                on: { liked: _vm.heartFillBig }
                              }),
                              _vm._v(" "),
                              _c("btn-comment", { attrs: { item: _vm.item } }),
                              _vm._v(" "),
                              _c("btn-share", { attrs: { item: _vm.item } })
                            ],
                            1
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "d-flex order-1 align-items-end" },
                            [
                              _c("btn-visit", {
                                staticClass: "ml-2",
                                attrs: { item: _vm.item }
                              }),
                              _vm._v(" "),
                              _c("btn-bookmark", {
                                attrs: { item: _vm.item },
                                on: { bookmarked: _vm.bookmarkFillBig }
                              })
                            ],
                            1
                          )
                        ]
                      )
                    : _c(
                        "div",
                        {
                          staticClass:
                            "d-flex order-0 justify-content-between d-print-none"
                        },
                        [
                          _c(
                            "div",
                            {
                              staticClass:
                                "d-flex align-items-center justify-content-end order-1 w-100"
                            },
                            [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "d-flex order-1 align-items-center"
                                },
                                [
                                  _c("btn-print", {
                                    attrs: { item: _vm.item }
                                  }),
                                  _vm._v(" "),
                                  _c("btn-share", {
                                    attrs: { item: _vm.item }
                                  }),
                                  _vm._v(" "),
                                  _c("btn-like", { attrs: { item: _vm.item } }),
                                  _vm._v(" "),
                                  _c("btn-bookmark", {
                                    attrs: { item: _vm.item }
                                  }),
                                  _vm._v(" "),
                                  _c("btn-visit", {
                                    staticClass: "ml-2",
                                    attrs: { item: _vm.item }
                                  })
                                ],
                                1
                              )
                            ]
                          )
                        ]
                      )
                ]
              ),
              _vm._v(" "),
              _c(
                "div",
                {
                  staticClass:
                    "mt-md-5 order-1 order-md-1 d-flex flex-column justify-content-center align-items-center"
                },
                [
                  _c("div", { staticClass: "text-center" }, [
                    _c("div", { staticClass: "h1" }, [
                      _vm._v(_vm._s(_vm.item.recipe.title))
                    ]),
                    _vm._v(" "),
                    _vm.item.recipe.subtitle
                      ? _c("div", { staticClass: "h2 text-secondary" }, [
                          _vm._v(_vm._s(_vm.item.recipe.subtitle))
                        ])
                      : _vm._e()
                  ])
                ]
              ),
              _vm._v(" "),
              !_vm.mobile
                ? _c("div", { staticClass: "my-5 d-print-none" }, [
                    _c("div", {
                      staticClass: "recipe-image",
                      style: {
                        backgroundImage:
                          "url(" + _vm.item.recipe.photo.full.url + ")"
                      }
                    })
                  ])
                : _vm._e(),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "d-none d-print-block mt-3 mb-5 text-center" },
                [_vm._v("∾ www.CuisinierRebelle.com ∾")]
              ),
              _vm._v(" "),
              !_vm.localhost
                ? _c(
                    "div",
                    { staticClass: "my-3 d-print-none" },
                    [
                      _c("InArticleAdsense", {
                        attrs: {
                          "data-ad-client": "ca-pub-9223566768445571",
                          "data-ad-slot": "4726766855"
                        }
                      })
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _c("vue-markdown", {
                attrs: { source: _vm.item.recipe.direction }
              }),
              _vm._v(" "),
              _vm.item.recipe.video
                ? _c("div", { staticClass: "row mt-5 d-print-none" }, [
                    _c("div", { staticClass: "col col-md-8 mx-auto" }, [
                      _c(
                        "div",
                        {
                          staticClass:
                            "rounded embed-responsive embed-responsive-16by9"
                        },
                        [
                          _c("iframe", {
                            staticClass: "embed-responsive-item",
                            attrs: {
                              src: _vm.item.recipe.video,
                              frameborder: "0",
                              allow:
                                "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture",
                              allowfullscreen: ""
                            }
                          })
                        ]
                      )
                    ])
                  ])
                : _vm._e(),
              _vm._v(" "),
              _c(
                "div",
                { staticClass: "d-print-none mt-5" },
                [
                  _c("div", { staticClass: "h4 mb-3" }, [
                    _vm._v(_vm._s(_vm.$t("recipe.otherRecipes")))
                  ]),
                  _vm._v(" "),
                  _vm._l(5, function(index) {
                    return _c("card-small", { key: "cs" + index })
                  })
                ],
                2
              ),
              _vm._v(" "),
              _c(
                "div",
                { ref: "comments", attrs: { id: "comments" } },
                [
                  _c("comments", {
                    attrs: { item: _vm.item },
                    on: { lastCommentMounted: _vm.lastCommentMounted }
                  })
                ],
                1
              )
            ],
            1
          )
        : _vm._e()
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=42-150247c57951b7db96e2.chunk.js.map