(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[44],{

/***/ "./app/javascript/vue/views/RecipeNew.vue":
/*!************************************************!*\
  !*** ./app/javascript/vue/views/RecipeNew.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _RecipeNew_vue_vue_type_template_id_60f22e42___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./RecipeNew.vue?vue&type=template&id=60f22e42& */ "./app/javascript/vue/views/RecipeNew.vue?vue&type=template&id=60f22e42&");
/* harmony import */ var _RecipeNew_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./RecipeNew.vue?vue&type=script&lang=js& */ "./app/javascript/vue/views/RecipeNew.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _RecipeNew_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _RecipeNew_vue_vue_type_template_id_60f22e42___WEBPACK_IMPORTED_MODULE_0__["render"],
  _RecipeNew_vue_vue_type_template_id_60f22e42___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/views/RecipeNew.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/views/RecipeNew.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./app/javascript/vue/views/RecipeNew.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecipeNew_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--6-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./RecipeNew.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/RecipeNew.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_RecipeNew_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/views/RecipeNew.vue?vue&type=template&id=60f22e42&":
/*!*******************************************************************************!*\
  !*** ./app/javascript/vue/views/RecipeNew.vue?vue&type=template&id=60f22e42& ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RecipeNew_vue_vue_type_template_id_60f22e42___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./RecipeNew.vue?vue&type=template&id=60f22e42& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/RecipeNew.vue?vue&type=template&id=60f22e42&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RecipeNew_vue_vue_type_template_id_60f22e42___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_RecipeNew_vue_vue_type_template_id_60f22e42___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/RecipeNew.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/views/RecipeNew.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'RecipeNew',
  data: function data() {
    return {
      // componentKey: 0,
      // navbarHeight: 0,
      title: null,
      subtitle: null,
      video: null,
      direction: '',
      description: '',
      // image: null,
      photo: null,
      tagList: null,
      disabled: true,
      max: 280,
      errors: []
    };
  },
  methods: {
    processFile: function processFile(event) {
      var _this = this;

      console.log(event);
      this.photo = event.target.files[0];
      console.log(this.photo);
      console.log(this.$refs.photo); // console.log(URL.createObjectURL(this.photo))
      // this.$refs.photo.src = URL.createObjectURL(this.photo)

      var reader = new FileReader();

      reader.onload = function () {
        // console.log(reader.result)
        _this.$refs.preview.innerHTML = '';

        _this.$refs.preview.insertAdjacentHTML('afterbegin', "<div class=\"mb-3\"><img src=\"".concat(reader.result, "\" class=\"rounded img-fluid\" alt=\"").concat(_this.photo.name, "\"></div>")); // this.$refs.photo.src = reader.result

      };

      reader.readAsDataURL(this.photo);
      this.allowPost();
    },
    allowPost: function allowPost() {
      if (this.title && this.direction && this.photo) {
        this.disabled = false;
      } else {
        this.disabled = true;
      }
    },
    validateYoutubeVideoUrl: function validateYoutubeVideoUrl(url) {
      var re = /(^$|^.*@.*\..*$)|youtu.?be/;
      return re.test(String(url).toLowerCase());
    },
    checkForm: function checkForm() {
      this.errors = [];

      if (!this.title) {
        this.errors.push(this.$t('recipe.new.errors.title'));
        return false;
      }

      if (!this.direction) {
        this.errors.push(this.$t('recipe.new.errors.direction'));
        return false;
      }

      if (!this.photo) {
        this.errors.push(this.$t('recipe.new.errors.photo'));
        return false;
      }

      if (this.video && !this.validateYoutubeVideoUrl(this.video)) {
        this.errors.push(this.$t('recipe.new.errors.youtubeVideoUrl'));
        return false;
      }

      return true;
    },
    postRecipe: function postRecipe() {
      var _this2 = this;

      var checkForm = this.checkForm();

      if (checkForm) {
        // console.log(this)
        this.disabled = true;
        var payload = {
          title: this.title,
          subtitle: this.subtitle,
          video: this.video,
          direction: this.direction,
          description: this.description,
          // image: null,
          // user_id: 0,
          photo: this.photo,
          tagList: this.tagList
        };
        console.log(payload);
        this.$store.dispatch('RECIPE_NEW', payload).then(function (response) {
          console.log(response);

          if (response.status === 200) {
            _this2.$router.push({
              name: 'Recipe',
              params: {
                id: response.data.recipe.slug
              }
            });
          }
        });
      } else {
        console.log(this.errors);
        this.$toast.open({
          message: this.errors[0],
          type: 'error',
          // success, info, warning, error, default
          // all of other options may go here
          position: 'bottom',
          // top, bottom, top-right, bottom-right,top-left, bottom-left
          duration: 3000,
          // Visibility duration in milliseconds
          dismissible: true
        });
      }
    } // getNavbarHeight () {
    //   return this.$store.getters.navbarHeight
    // },

  },
  computed: _objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapGetters"])(['navbarHeight'])),
  mounted: function mounted() {// this.navbarHeight = this.getNavbarHeight()
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/RecipeNew.vue?vue&type=template&id=60f22e42&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/views/RecipeNew.vue?vue&type=template&id=60f22e42& ***!
  \*************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "container",
      style: { paddingTop: _vm.navbarHeight + "px" }
    },
    [
      _c("div", { staticClass: "py-3" }, [
        _c("form", { on: { input: _vm.allowPost, touchend: _vm.allowPost } }, [
          _c("div", { staticClass: "form-group mb-3" }, [
            _c("label", { attrs: { for: "inputRecipeTitle" } }, [
              _vm._v(_vm._s(_vm.$t("recipe.new.title")))
            ]),
            _vm._v(" "),
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.title,
                  expression: "title"
                }
              ],
              staticClass: "form-control",
              attrs: { type: "text", id: "inputRecipeTitle" },
              domProps: { value: _vm.title },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.title = $event.target.value
                }
              }
            })
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "form-group mb-3" }, [
            _c("label", { attrs: { for: "inputRecipeSubtitle" } }, [
              _vm._v(_vm._s(_vm.$t("recipe.new.subtitle")))
            ]),
            _vm._v(" "),
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.subtitle,
                  expression: "subtitle"
                }
              ],
              staticClass: "form-control",
              attrs: { type: "text", id: "inputRecipeSubtitle" },
              domProps: { value: _vm.subtitle },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.subtitle = $event.target.value
                }
              }
            })
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "form-group mb-3" }, [
            _c("label", { attrs: { for: "inputRecipedescription" } }, [
              _vm._v(_vm._s(_vm.$t("recipe.new.description")))
            ]),
            _vm._v(" "),
            _c("textarea", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.description,
                  expression: "description"
                }
              ],
              staticClass: "form-control",
              attrs: {
                maxlength: _vm.max,
                id: "inputRecipedescription",
                rows: "3"
              },
              domProps: { value: _vm.description },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.description = $event.target.value
                }
              }
            }),
            _vm._v(" "),
            _c(
              "small",
              {
                staticClass: "form-text text-muted",
                attrs: { id: "descriptionHelpBlock" }
              },
              [
                _vm._v(
                  "\n          " +
                    _vm._s(
                      _vm.$tc(
                        "recipe.new.descriptionHelp",
                        _vm.max - _vm.description.length
                      )
                    ) +
                    "\n        "
                )
              ]
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "form-group mb-3" }, [
            _c("label", { attrs: { for: "inputRecipeDirection" } }, [
              _vm._v(_vm._s(_vm.$t("recipe.new.direction")))
            ]),
            _vm._v(" "),
            _c("textarea", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.direction,
                  expression: "direction"
                }
              ],
              staticClass: "form-control",
              attrs: { id: "inputRecipeDirection", rows: "10" },
              domProps: { value: _vm.direction },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.direction = $event.target.value
                }
              }
            })
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "mb-2" }, [
            _vm._v(_vm._s(_vm.$t("recipe.new.photo")))
          ]),
          _vm._v(" "),
          _c("div", { ref: "photo", staticClass: "form-group mb-3" }, [
            _c("div", { staticClass: "custom-file" }, [
              _c("input", {
                staticClass: "custom-file-input",
                attrs: { type: "file", id: "photoFileLangHTML" },
                on: {
                  change: function($event) {
                    return _vm.processFile($event)
                  }
                }
              }),
              _vm._v(" "),
              _c(
                "label",
                {
                  staticClass: "custom-file-label",
                  attrs: {
                    for: "photoFileLangHTML",
                    "data-browse": _vm.$t("recipe.new.chooseFile")
                  }
                },
                [_vm._v(_vm._s(_vm.$t("recipe.new.browse")))]
              )
            ])
          ]),
          _vm._v(" "),
          _c("div", { ref: "preview" }),
          _vm._v(" "),
          _c("div", { staticClass: "form-group mb-3" }, [
            _c("label", { attrs: { for: "inputRecipeVideo" } }, [
              _vm._v(_vm._s(_vm.$t("recipe.new.video")))
            ]),
            _vm._v(" "),
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.video,
                  expression: "video"
                }
              ],
              staticClass: "form-control",
              attrs: { type: "url", id: "inputRecipeVideo" },
              domProps: { value: _vm.video },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.video = $event.target.value
                }
              }
            })
          ]),
          _vm._v(" "),
          _c("label", { attrs: { for: "inputRecipeTags" } }, [
            _vm._v(_vm._s(_vm.$t("recipe.new.tags")))
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "form-group mb-3" }, [
            _c("textarea", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.tagList,
                  expression: "tagList"
                }
              ],
              staticClass: "form-control",
              attrs: { id: "inputRecipeTags", rows: "3" },
              domProps: { value: _vm.tagList },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.tagList = $event.target.value
                }
              }
            }),
            _vm._v(" "),
            _c(
              "small",
              {
                staticClass: "form-text text-muted",
                attrs: { id: "tagsHelpBlock" }
              },
              [
                _vm._v(
                  "\n          " +
                    _vm._s(_vm.$t("recipe.new.tagsHelp")) +
                    "\n        "
                )
              ]
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "d-flex justify-content-end" }, [
            _c(
              "button",
              {
                staticClass: "btn btn-dark mb-3",
                attrs: { type: "submit", disabled: _vm.disabled },
                on: {
                  click: function($event) {
                    $event.stopPropagation()
                    $event.preventDefault()
                    return _vm.postRecipe($event)
                  }
                }
              },
              [_vm._v(_vm._s(_vm.$t("recipe.new.submit")))]
            )
          ])
        ])
      ])
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=44-cf444ddfba064d86dd6b.chunk.js.map