(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[24],{

/***/ "./app/javascript/vue/components/NavbarSmall.vue":
/*!*******************************************************!*\
  !*** ./app/javascript/vue/components/NavbarSmall.vue ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _NavbarSmall_vue_vue_type_template_id_f17c0586___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./NavbarSmall.vue?vue&type=template&id=f17c0586& */ "./app/javascript/vue/components/NavbarSmall.vue?vue&type=template&id=f17c0586&");
/* harmony import */ var _NavbarSmall_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./NavbarSmall.vue?vue&type=script&lang=js& */ "./app/javascript/vue/components/NavbarSmall.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _NavbarSmall_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _NavbarSmall_vue_vue_type_template_id_f17c0586___WEBPACK_IMPORTED_MODULE_0__["render"],
  _NavbarSmall_vue_vue_type_template_id_f17c0586___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/components/NavbarSmall.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/components/NavbarSmall.vue?vue&type=script&lang=js&":
/*!********************************************************************************!*\
  !*** ./app/javascript/vue/components/NavbarSmall.vue?vue&type=script&lang=js& ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarSmall_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--6-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarSmall.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/NavbarSmall.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarSmall_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/components/NavbarSmall.vue?vue&type=template&id=f17c0586&":
/*!**************************************************************************************!*\
  !*** ./app/javascript/vue/components/NavbarSmall.vue?vue&type=template&id=f17c0586& ***!
  \**************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarSmall_vue_vue_type_template_id_f17c0586___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./NavbarSmall.vue?vue&type=template&id=f17c0586& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/NavbarSmall.vue?vue&type=template&id=f17c0586&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarSmall_vue_vue_type_template_id_f17c0586___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_NavbarSmall_vue_vue_type_template_id_f17c0586___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/NavbarSmall.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/NavbarSmall.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var mobile_device_detect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! mobile-device-detect */ "./node_modules/mobile-device-detect/dist/index.js");
/* harmony import */ var mobile_device_detect__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobile_device_detect__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vue_click_outside__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-click-outside */ "./node_modules/vue-click-outside/index.js");
/* harmony import */ var vue_click_outside__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vue_click_outside__WEBPACK_IMPORTED_MODULE_3__);


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'NavbarSmall',
  data: function data() {
    return {
      componentKey: 0,
      show: false,
      searchQuery: ''
    };
  },
  directives: {
    ClickOutside: vue_click_outside__WEBPACK_IMPORTED_MODULE_3___default.a
  },
  // components: {
  //   // Navbar
  // },
  created: function created() {
    window.addEventListener('scroll', this.handleScroll);
  },
  destroyed: function destroyed() {
    window.removeEventListener('scroll', this.handleScroll);
  },
  methods: {
    inputMode: function inputMode() {
      // this.$refs.searchInput.inputMode = 'search'
      // this.$refs.searchInput.inputMode = 'none'
      if (this.show === false) {
        console.log('inputMode'); // this.$refs.searchInput.value = ''

        this.searchQuery = '';
        this.$refs.searchInput.blur();
      }
    },
    validSearchQuery: function validSearchQuery() {
      var _this = this;

      console.log(this.searchQuery);
      this.$store.dispatch('SEARCH', {
        query: this.searchQuery
      }).then(function (response) {
        console.log(response);
        if (response.status === 200) _this.$router.push({
          name: 'Search',
          query: {
            r: _this.searchQuery
          }
        });
      })["finally"](function () {
        return _this.inputMode();
      }); // this.inputMode()
    },
    collapseMenu: function collapseMenu() {
      var _this2 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee() {
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                _context.next = 2;
                return _this2.inputMode();

              case 2:
                _this2.show = !_this2.show;

              case 3:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }))();
    },
    collapse: function collapse() {
      var _this3 = this;

      return _asyncToGenerator( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee2() {
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                _context2.next = 2;
                return _this3.inputMode();

              case 2:
                _this3.show = false;

              case 3:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }))();
    },
    scroll2Top: function scroll2Top(event) {
      this.collapse(); // console.log(this.$route.name)

      if (this.$route.name === 'Home' && window.scrollY > 0) {
        event.preventDefault();
        var scrollOptions = {
          top: 0,
          left: 0,
          behavior: 'smooth'
        };
        window.scrollTo(scrollOptions);
      }
    },
    handleScroll: function handleScroll(event) {
      this.collapse(); // Code to be executed when the window is scrolled

      var position = window.scrollY != 0; // console.log(position)

      if (position) this.$refs.navbar.classList.add('border-bottom');else this.$refs.navbar.classList.remove('border-bottom');
      return position;
    },
    logout: function logout() {
      var _this4 = this;

      this.collapse();
      var message = this.$t('navbar.are_you_sure');
      var options = {
        // html: false, // set to true if your message contains HTML tags. eg: "Delete <b>Foo</b> ?"
        // loader: false, // set to true if you want the dailog to show a loader after click on "proceed"
        // reverse: false, // switch the button positions (left to right, and vise versa)
        okText: this.$t('navbar.logout'),
        cancelText: this.$t('navbar.cancel'),
        // animation: 'zoom', // Available: "zoom", "bounce", "fade"
        // type: 'basic', // coming soon: 'soft', 'hard'
        // verification: 'continue', // for hard confirm, user will be prompted to type this to enable the proceed button
        // verificationHelp: 'Type "[+:verification]" below to confirm', // Verification help text. [+:verification] will be matched with 'options.verification' (i.e 'Type "continue" below to confirm')
        // clicksCount: 3, // for soft confirm, user will be asked to click on "proceed" btn 3 times before actually proceeding
        backdropClose: true,
        // set to true to close the dialog when clicking outside of the dialog window, i.e. click landing on the mask
        customClass: '' // Custom class to be injected into the parent node for the current dialog instance

      };
      this.$dialog.confirm(message, options).then(function (dialog) {
        console.log('Clicked on proceed');
        console.log(dialog);

        _this4.$store.dispatch('LOG_OUT', {}).then(function (response) {
          console.log(response);
          if (response.status === 204 && _this4.$route.name != 'Home') _this4.$router.push({
            name: 'Home'
          });
        });
      })["catch"](function () {
        console.log('Clicked on cancel');
      });
    },
    forceRerender: function forceRerender() {
      this.componentKey += 1;
    },
    navbarHeight: function navbarHeight() {
      this.$store.dispatch('NAVBAR_HEIGHT', parseInt(this.$refs.navbar.offsetHeight));
    }
  },
  computed: _objectSpread(_objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['isAuthenticated', 'currentUser'])), {}, {
    user: function user() {
      return this.currentUser;
    },
    isScrollTop: function isScrollTop() {
      return true;
    },
    // user () {
    //   return this.$store.getters.currentUser
    // },
    // isAuthenticated () {
    //   // console.log(this.$store)
    //   // console.log(this.$store.state.data.isAuthenticated)
    //   // console.log(this.$store.getters.isAuthenticated)
    //   return this.$store.getters.isAuthenticated
    // },
    // items () {
    //   return this.filter
    // },
    mobile: function mobile() {
      return mobile_device_detect__WEBPACK_IMPORTED_MODULE_2__["isMobile"];
    }
  }),
  beforeMount: function beforeMount() {
    this.forceRerender();
  },
  mounted: function mounted() {
    this.navbarHeight();
    this.handleScroll();
  }
});

/***/ }),

/***/ "./node_modules/vue-click-outside/index.js":
/*!*************************************************!*\
  !*** ./node_modules/vue-click-outside/index.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function validate(binding) {
  if (typeof binding.value !== 'function') {
    console.warn('[Vue-click-outside:] provided expression', binding.expression, 'is not a function.')
    return false
  }

  return true
}

function isPopup(popupItem, elements) {
  if (!popupItem || !elements)
    return false

  for (var i = 0, len = elements.length; i < len; i++) {
    try {
      if (popupItem.contains(elements[i])) {
        return true
      }
      if (elements[i].contains(popupItem)) {
        return false
      }
    } catch(e) {
      return false
    }
  }

  return false
}

function isServer(vNode) {
  return typeof vNode.componentInstance !== 'undefined' && vNode.componentInstance.$isServer
}

exports = module.exports = {
  bind: function (el, binding, vNode) {
    if (!validate(binding)) return

    // Define Handler and cache it on the element
    function handler(e) {
      if (!vNode.context) return

      // some components may have related popup item, on which we shall prevent the click outside event handler.
      var elements = e.path || (e.composedPath && e.composedPath())
      elements && elements.length > 0 && elements.unshift(e.target)

      if (el.contains(e.target) || isPopup(vNode.context.popupItem, elements)) return

      el.__vueClickOutside__.callback(e)
    }

    // add Event Listeners
    el.__vueClickOutside__ = {
      handler: handler,
      callback: binding.value
    }
    const clickHandler = 'ontouchstart' in document.documentElement ? 'touchstart' : 'click';
    !isServer(vNode) && document.addEventListener(clickHandler, handler)
  },

  update: function (el, binding) {
    if (validate(binding)) el.__vueClickOutside__.callback = binding.value
  },

  unbind: function (el, binding, vNode) {
    // Remove Event Listeners
    const clickHandler = 'ontouchstart' in document.documentElement ? 'touchstart' : 'click';
    !isServer(vNode) && el.__vueClickOutside__ && document.removeEventListener(clickHandler, el.__vueClickOutside__.handler)
    delete el.__vueClickOutside__
  }
}


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/NavbarSmall.vue?vue&type=template&id=f17c0586&":
/*!********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/NavbarSmall.vue?vue&type=template&id=f17c0586& ***!
  \********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      directives: [
        {
          name: "click-outside",
          rawName: "v-click-outside",
          value: _vm.collapse,
          expression: "collapse"
        }
      ],
      key: _vm.componentKey,
      ref: "navbar",
      class: ["navbar fixed-top d-flex flex-column px-3 py-2 bg-white"]
    },
    [
      _c(
        "div",
        {
          staticClass: "d-flex w-100 justify-content-between align-items-center"
        },
        [
          _c(
            "div",
            { staticClass: "d-flex align-items-center" },
            [
              _c(
                "router-link",
                {
                  staticClass:
                    "navbar-brand d-flex align-items-center text-body",
                  attrs: { to: "/" },
                  nativeOn: {
                    click: function($event) {
                      return _vm.scroll2Top($event)
                    }
                  }
                },
                [
                  _c("img", {
                    directives: [
                      {
                        name: "lazy",
                        rawName: "v-lazy",
                        value:
                          "https://media.cuisinierrebelle.com/brand-icon.jpg",
                        expression:
                          "'https://media.cuisinierrebelle.com/brand-icon.jpg'"
                      }
                    ],
                    staticClass: "mr-1",
                    attrs: { width: "32", height: "32" }
                  }),
                  _vm._v(" "),
                  _c("span", [_vm._v(_vm._s(_vm.$t("navbar.brand")))])
                ]
              )
            ],
            1
          ),
          _vm._v(" "),
          _c("div", { on: { click: _vm.collapseMenu } }, [
            _c("i", { staticClass: "material-icons md-24 d-flex" }, [
              _vm._v("menu")
            ])
          ])
        ]
      ),
      _vm._v(" "),
      _c("transition", { attrs: { name: "fade" } }, [
        !_vm.show
          ? _c("div", { staticClass: "mt-2 input-group d-flex w-100" }, [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.searchQuery,
                    expression: "searchQuery"
                  }
                ],
                ref: "searchInput",
                staticClass: "form-control",
                attrs: { type: "search", placeholder: _vm.$t("navbar.search") },
                domProps: { value: _vm.searchQuery },
                on: {
                  keyup: function($event) {
                    if (
                      !$event.type.indexOf("key") &&
                      _vm._k($event.keyCode, "enter", 13, $event.key, "Enter")
                    ) {
                      return null
                    }
                    return _vm.validSearchQuery($event)
                  },
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.searchQuery = $event.target.value
                  }
                }
              })
            ])
          : _vm._e(),
        _vm._v(" "),
        _vm.show
          ? _c("div", { staticClass: "mt-2 d-flex flex-column w-100" }, [
              _vm.isAuthenticated
                ? _c(
                    "div",
                    { staticClass: "d-flex flex-column" },
                    [
                      _c(
                        "router-link",
                        {
                          staticClass: "text-fire my-2 text-decoration-none",
                          attrs: { to: "/top100" },
                          nativeOn: {
                            click: function($event) {
                              return _vm.collapse($event)
                            }
                          }
                        },
                        [_vm._v("Top 100")]
                      ),
                      _vm._v(" "),
                      _c(
                        "router-link",
                        {
                          staticClass: "text-body my-2 text-decoration-none",
                          attrs: { to: "/bookmarks" },
                          nativeOn: {
                            click: function($event) {
                              return _vm.collapse($event)
                            }
                          }
                        },
                        [_vm._v(_vm._s(_vm.$t("navbar.bookmarks")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "router-link",
                        {
                          staticClass: "text-body my-2 text-decoration-none",
                          attrs: { to: "/u/" + _vm.user.slug },
                          nativeOn: {
                            click: function($event) {
                              return _vm.collapse($event)
                            }
                          }
                        },
                        [_vm._v(_vm._s(_vm.$t("navbar.recipes")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "router-link",
                        {
                          staticClass: "text-body my-2 text-decoration-none",
                          attrs: { to: "/r/new" },
                          nativeOn: {
                            click: function($event) {
                              return _vm.collapse($event)
                            }
                          }
                        },
                        [_vm._v(_vm._s(_vm.$t("navbar.new_recipe")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "router-link",
                        {
                          staticClass: "text-body my-2 text-decoration-none",
                          attrs: { to: "/u/" + _vm.user.slug + "/following" },
                          nativeOn: {
                            click: function($event) {
                              return _vm.collapse($event)
                            }
                          }
                        },
                        [_vm._v(_vm._s(_vm.$t("navbar.following")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "router-link",
                        {
                          staticClass: "text-body my-2 text-decoration-none",
                          attrs: { to: "/u/" + _vm.user.slug + "/settings" },
                          nativeOn: {
                            click: function($event) {
                              return _vm.collapse($event)
                            }
                          }
                        },
                        [_vm._v(_vm._s(_vm.$t("navbar.settings")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass: "text-body my-2 text-decoration-none",
                          on: { click: _vm.logout }
                        },
                        [_vm._v(_vm._s(_vm.$t("navbar.logout")))]
                      )
                    ],
                    1
                  )
                : _c(
                    "div",
                    { staticClass: "d-flex flex-column" },
                    [
                      _c(
                        "router-link",
                        {
                          staticClass: "text-body my-2 text-decoration-none",
                          attrs: { to: "/login" },
                          nativeOn: {
                            click: function($event) {
                              return _vm.collapse($event)
                            }
                          }
                        },
                        [_vm._v(_vm._s(_vm.$t("navbar.login")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "router-link",
                        {
                          staticClass: "text-body my-2 text-decoration-none",
                          attrs: { to: "/signup" },
                          nativeOn: {
                            click: function($event) {
                              return _vm.collapse($event)
                            }
                          }
                        },
                        [_vm._v(_vm._s(_vm.$t("navbar.getStarted")))]
                      )
                    ],
                    1
                  )
            ])
          : _vm._e()
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=24-62f4878f599cdd919c2a.chunk.js.map