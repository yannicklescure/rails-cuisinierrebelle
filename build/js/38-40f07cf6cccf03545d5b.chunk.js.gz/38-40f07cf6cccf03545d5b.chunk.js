(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[38],{

/***/ "./app/javascript/vue/views/Home.vue":
/*!*******************************************!*\
  !*** ./app/javascript/vue/views/Home.vue ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Home_vue_vue_type_template_id_19b6b97f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Home.vue?vue&type=template&id=19b6b97f& */ "./app/javascript/vue/views/Home.vue?vue&type=template&id=19b6b97f&");
/* harmony import */ var _Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Home.vue?vue&type=script&lang=js& */ "./app/javascript/vue/views/Home.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Home_vue_vue_type_template_id_19b6b97f___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Home_vue_vue_type_template_id_19b6b97f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/views/Home.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/views/Home.vue?vue&type=script&lang=js&":
/*!********************************************************************!*\
  !*** ./app/javascript/vue/views/Home.vue?vue&type=script&lang=js& ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--6-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Home.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Home.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/views/Home.vue?vue&type=template&id=19b6b97f&":
/*!**************************************************************************!*\
  !*** ./app/javascript/vue/views/Home.vue?vue&type=template&id=19b6b97f& ***!
  \**************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_19b6b97f___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Home.vue?vue&type=template&id=19b6b97f& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Home.vue?vue&type=template&id=19b6b97f&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_19b6b97f___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_19b6b97f___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Home.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/views/Home.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

 // import Banner from '../components/Banner.vue'
// import Card from '../components/Card.vue'

var Banner = function Banner() {
  return Promise.all(/*! import() */[__webpack_require__.e(56), __webpack_require__.e(12), __webpack_require__.e(53), __webpack_require__.e(26)]).then(__webpack_require__.bind(null, /*! ../components/Banner.vue */ "./app/javascript/vue/components/Banner.vue"));
};

var Card = function Card() {
  return __webpack_require__.e(/*! import() */ 0).then(__webpack_require__.bind(null, /*! ../components/Card.vue */ "./app/javascript/vue/components/Card.vue"));
};

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Home',
  data: function data() {
    return {
      componentKey: 0,
      // navbarHeight: 0,
      data: [],
      busy: false
    };
  },
  metaInfo: {
    title: 'Cuisinier Rebelle',
    // override the parent template and just use the above title only
    titleTemplate: null
  },
  components: {
    Card: Card,
    Banner: Banner
  },
  computed: _objectSpread(_objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_0__["mapGetters"])(['navbarHeight', 'recipes', 'isAuthenticated'])), {}, {
    items: function items() {
      return this.recipes;
    } // items () {
    //   const items = this.$store.getters.recipes
    //   // if (items && this.data.length === 0) this.data = items.slice(0, 24)
    //   return items
    // },
    // setData () {
    //   if (this.items.length > 0 && this.data.length === 0) {
    //     this.data = this.items.slice(0, 24)
    //     return true
    //   }
    //   return false
    // },

  }),
  // watch: {
  //   items () {
  //     // this.loadMore()
  //     console.log('items loaded')
  //   }
  // },
  methods: {
    // cardParams (value) {
    //   const cardWidth = value.params.width
    //   console.log(cardWidth)
    //   const containerWidth = this.$refs.container.offsetWidth
    //   console.log(containerWidth)
    //   console.log(containerWidth / cardWidth)
    // },
    loadMore: function loadMore() {
      var _this = this;

      if (this.data.length < this.items.length) {
        console.log('loadMore');
        this.busy = true;
        setTimeout(function () {
          var cards = 24;
          var min = _this.data.length;
          var max = min + cards <= _this.items.length ? min + cards : _this.items.length;

          for (var i = min, j = max; i < j; i++) {
            _this.data.push(_this.items[i]);
          }

          _this.busy = false;
        }, 0);
      }
    },
    fetchItem: function fetchItem() {
      var _this2 = this;

      if (this.recipes.length === 0) {
        console.log('fetching recipes data');
        this.$store.dispatch('RECIPES', {}).then(function (response) {
          console.log(response.data.data.recipes);
          _this2.data = response.data.data.recipes.sort(function (a, b) {
            return a.timestamp > b.timestamp ? 1 : -1;
          }).reverse().splice(0, 24);
        });
      } else {
        this.loadMore();
      }
    }
  },
  beforeMount: function beforeMount() {
    this.fetchItem(); // this.loadMore()
  },
  mounted: function mounted() {
    // while (this.data.length === 0){
    //   if (this.recipes.length > 0 && this.data.length === 0) this.data = this.recipes.slice(0, 24)
    // }
    this.$nextTick(function () {
      // this.navbarHeight = this.$store.getters.navbarHeight
      // console.log(this.$store.getters.navbarHeight)
      // console.log(this.$store.getters.recipes)
      // if (this.items.length > 0) console.log('items ready')
      setTimeout(function () {// this.loadMore()
        // while (!this.items && this.data.length === 0) this.loadMore()
      }, 1000); // console.log(this.data)
    });
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/views/Home.vue?vue&type=template&id=19b6b97f&":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/views/Home.vue?vue&type=template&id=19b6b97f& ***!
  \********************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { style: { paddingTop: _vm.navbarHeight + "px" } },
    [
      !_vm.isAuthenticated ? _c("banner") : _vm._e(),
      _vm._v(" "),
      _c("div", { ref: "container", staticClass: "container-fluid" }, [
        _c("div", { attrs: { id: "recipes-cards" } }, [
          _c(
            "div",
            {
              staticClass: "d-flex flex-wrap justify-content-start py-3",
              attrs: { id: "root" }
            },
            _vm._l(_vm.data, function(item, index) {
              return _c(
                "div",
                { key: item.id, staticClass: "card rounded border-0" },
                [_c("card", { attrs: { item: item } })],
                1
              )
            }),
            0
          ),
          _vm._v(" "),
          _c("div", {
            directives: [
              {
                name: "infinite-scroll",
                rawName: "v-infinite-scroll",
                value: _vm.loadMore,
                expression: "loadMore"
              }
            ],
            attrs: {
              "infinite-scroll-disabled": "busy",
              "infinite-scroll-distance": "navbarHeight",
              "infinite-scroll-immediate-check": "true"
            }
          })
        ])
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=38-40f07cf6cccf03545d5b.chunk.js.map