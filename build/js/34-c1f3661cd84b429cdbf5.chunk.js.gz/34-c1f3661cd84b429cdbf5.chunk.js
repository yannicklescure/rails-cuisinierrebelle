(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[34],{

/***/ "./app/javascript/vue/components/buttons/SocialSharingModal.vue":
/*!**********************************************************************!*\
  !*** ./app/javascript/vue/components/buttons/SocialSharingModal.vue ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SocialSharingModal_vue_vue_type_template_id_7eee8fd4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SocialSharingModal.vue?vue&type=template&id=7eee8fd4& */ "./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=template&id=7eee8fd4&");
/* harmony import */ var _SocialSharingModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SocialSharingModal.vue?vue&type=script&lang=js& */ "./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SocialSharingModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SocialSharingModal_vue_vue_type_template_id_7eee8fd4___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SocialSharingModal_vue_vue_type_template_id_7eee8fd4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/components/buttons/SocialSharingModal.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=script&lang=js&":
/*!***********************************************************************************************!*\
  !*** ./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=script&lang=js& ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialSharingModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--6-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SocialSharingModal.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialSharingModal_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=template&id=7eee8fd4&":
/*!*****************************************************************************************************!*\
  !*** ./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=template&id=7eee8fd4& ***!
  \*****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialSharingModal_vue_vue_type_template_id_7eee8fd4___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SocialSharingModal.vue?vue&type=template&id=7eee8fd4& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=template&id=7eee8fd4&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialSharingModal_vue_vue_type_template_id_7eee8fd4___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialSharingModal_vue_vue_type_template_id_7eee8fd4___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
// import SocialSharing from './SocialSharing.vue'
var SocialSharing = function SocialSharing() {
  return Promise.all(/*! import() */[__webpack_require__.e(55), __webpack_require__.e(60), __webpack_require__.e(61), __webpack_require__.e(33)]).then(__webpack_require__.bind(null, /*! ./SocialSharing.vue */ "./app/javascript/vue/components/buttons/SocialSharing.vue"));
};

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SocialSharingModal',
  data: function data() {
    return {
      contentCopy: 'content_copy'
    };
  },
  props: ['item'],
  components: {
    SocialSharing: SocialSharing
  },
  methods: {
    shareItemDesktop: function shareItemDesktop() {
      var _this = this;

      console.log(this.item.recipe.id);
      var text = "".concat(window.location.origin, "/r/").concat(this.item.recipe.slug);
      console.log(text);
      navigator.clipboard.writeText(text).then(function () {
        console.log('Async: Copying to clipboard was successful!');
        _this.contentCopy = 'done';
      }, function (err) {
        console.error('Async: Could not copy text: ', err);
        _this.contentCopy = 'error';
      })["finally"](function () {
        setTimeout(function () {
          // const alert = document.querySelector('.alert')
          // if (alert) fade(alert).remove()
          _this.contentCopy = 'content_copy';
        }, 1500);
      });
    }
  },
  computed: {
    itemCurrentUrl: function itemCurrentUrl() {
      var url = "".concat(window.location.origin, "/r/").concat(this.item.recipe.slug); // const url = 'https://www.cuisinierrebelle.com/r/plat-facile-2-viandes-4-legumes-pour-lendemain-de-fetes'

      return url.length >= 68 ? "".concat(url.substring(0, 65), "...") : url;
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=template&id=7eee8fd4&":
/*!***********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/buttons/SocialSharingModal.vue?vue&type=template&id=7eee8fd4& ***!
  \***********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      ref: "modal-" + _vm.item.recipe.id,
      staticClass: "modal fade",
      attrs: {
        id: "modal-" + _vm.item.recipe.id,
        tabindex: "-1",
        role: "dialog",
        "aria-labelledby": "shareModalLabel",
        "aria-hidden": "true"
      }
    },
    [
      _c(
        "div",
        { staticClass: "modal-dialog modal-lg", attrs: { role: "document" } },
        [
          _c("div", { staticClass: "modal-content" }, [
            _c(
              "div",
              { staticClass: "modal-header d-flex align-items-center" },
              [
                _c(
                  "h5",
                  {
                    staticClass: "modal-title",
                    attrs: { id: "shareModalLabel" }
                  },
                  [
                    _c("span", { staticClass: "ml-2" }, [
                      _vm._v(_vm._s(_vm.$t("item.share")))
                    ])
                  ]
                ),
                _vm._v(" "),
                _vm._m(0)
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "modal-body" },
              [_c("social-sharing", { attrs: { item: _vm.item } })],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "modal-footer d-flex justify-content-between" },
              [
                _c("span", { staticClass: "text-secondary" }, [
                  _vm._v(_vm._s(_vm.itemCurrentUrl))
                ]),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn btn-sm d-flex align-items-center",
                    attrs: { href: "javascript:void(0)" },
                    on: { click: _vm.shareItemDesktop }
                  },
                  [
                    _c("span", { staticClass: "material-icons md-18 mr-2" }, [
                      _vm._v(_vm._s(_vm.contentCopy))
                    ]),
                    _vm._v(
                      _vm._s(_vm.$t("item.copy_to_clipboard")) + "\n        "
                    )
                  ]
                )
              ]
            )
          ])
        ]
      )
    ]
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "button",
      {
        staticClass: "btn btn-sm close",
        attrs: {
          type: "button",
          "data-dismiss": "modal",
          "aria-label": "Close"
        }
      },
      [_c("span", { attrs: { "aria-hidden": "true" } }, [_vm._v("×")])]
    )
  }
]
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=34-c1f3661cd84b429cdbf5.chunk.js.map