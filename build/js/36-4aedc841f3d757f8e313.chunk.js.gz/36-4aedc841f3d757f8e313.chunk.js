(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[36],{

/***/ "./app/javascript/vue/components/comments/Show.vue":
/*!*********************************************************!*\
  !*** ./app/javascript/vue/components/comments/Show.vue ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Show_vue_vue_type_template_id_45d040de___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Show.vue?vue&type=template&id=45d040de& */ "./app/javascript/vue/components/comments/Show.vue?vue&type=template&id=45d040de&");
/* harmony import */ var _Show_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Show.vue?vue&type=script&lang=js& */ "./app/javascript/vue/components/comments/Show.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Show_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Show_vue_vue_type_template_id_45d040de___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Show_vue_vue_type_template_id_45d040de___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/components/comments/Show.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/components/comments/Show.vue?vue&type=script&lang=js&":
/*!**********************************************************************************!*\
  !*** ./app/javascript/vue/components/comments/Show.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Show_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--6-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Show.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/comments/Show.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Show_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/components/comments/Show.vue?vue&type=template&id=45d040de&":
/*!****************************************************************************************!*\
  !*** ./app/javascript/vue/components/comments/Show.vue?vue&type=template&id=45d040de& ***!
  \****************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Show_vue_vue_type_template_id_45d040de___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./Show.vue?vue&type=template&id=45d040de& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/comments/Show.vue?vue&type=template&id=45d040de&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Show_vue_vue_type_template_id_45d040de___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Show_vue_vue_type_template_id_45d040de___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/comments/Show.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/comments/Show.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_markdown__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-markdown */ "./node_modules/vue-markdown/dist/vue-markdown.common.js");
/* harmony import */ var vue_markdown__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_markdown__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js");
/* harmony import */ var mobile_device_detect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! mobile-device-detect */ "./node_modules/mobile-device-detect/dist/index.js");
/* harmony import */ var mobile_device_detect__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobile_device_detect__WEBPACK_IMPORTED_MODULE_2__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


 // import CommentForm from './Form.vue'
// import CommentLike from '../buttons/CommentLike.vue'

var CommentForm = function CommentForm() {
  return __webpack_require__.e(/*! import() */ 13).then(__webpack_require__.bind(null, /*! ./Form.vue */ "./app/javascript/vue/components/comments/Form.vue"));
};

var CommentLike = function CommentLike() {
  return __webpack_require__.e(/*! import() */ 31).then(__webpack_require__.bind(null, /*! ../buttons/CommentLike.vue */ "./app/javascript/vue/components/buttons/CommentLike.vue"));
};

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'Comment',
  props: ['item', 'type', 'lastCommentId'],
  data: function data() {
    return {
      edit: false,
      reply: false
    };
  },
  components: {
    CommentForm: CommentForm,
    CommentLike: CommentLike,
    VueMarkdown: vue_markdown__WEBPACK_IMPORTED_MODULE_0___default.a
  },
  computed: _objectSpread(_objectSpread({}, Object(vuex__WEBPACK_IMPORTED_MODULE_1__["mapGetters"])(['isAuthenticated', 'currentUser', 'navbarHeight'])), {}, {
    mobile: function mobile() {
      return mobile_device_detect__WEBPACK_IMPORTED_MODULE_2__["isMobile"];
    }
  }),
  methods: {
    editActionAttr: function editActionAttr() {
      if (this.item.commentId) return 'REPLY_EDIT';else return 'COMMENT_EDIT';
    },
    commentReply: function commentReply() {
      console.log('reply');
      this.reply = true;
    },
    commentEdit: function commentEdit() {
      this.edit = true;
    },
    commentDrop: function commentDrop() {
      this.edit = false;
      this.reply = false;
      return false;
    },
    commentReplyNew: function commentReplyNew(payload) {
      console.log(payload);
      this.$emit('commentReplyNew', payload);
      this.reply = false; // this.item.content = value.data.content
    },
    commentEditResponse: function commentEditResponse(payload) {
      var _this = this;

      this.edit = false;

      if (this.item.commentId) {
        console.log(payload);
        console.log(this.item); // reply id : this.item.id
        // reply content : this.item.content
        // reply comment : this.item.commentId

        var reply = payload.data.replies.filter(function (r) {
          return r.id === _this.item.id;
        })[0];
        this.item.content = reply.content;
      } else {
        this.item.content = payload.data.content;
      }
    },
    commentDestroy: function commentDestroy() {
      var _this2 = this;

      var actionAttr = '';
      var payload = {};

      if (this.type === 'comment') {
        // console.log(`delete comment ${ this.item.id }`)
        payload = {
          comment_id: this.item.id,
          recipe_id: this.item.recipe.id,
          type: this.type
        };
        actionAttr = 'COMMENT_DELETE';
      }

      if (this.type === 'reply') {
        // console.log(`delete comment ${ this.item.id }`)
        payload = {
          comment_id: this.item.commentId,
          recipe_id: this.item.recipeId,
          id: this.item.id,
          type: this.type
        };
        actionAttr = 'REPLY_DELETE';
      }

      this.$store.dispatch(actionAttr, payload).then(function (response) {
        console.log(response);

        if (response.status === 204) {
          _this2.$emit('commentDestroyed', payload);
        }
      });
    },
    timeAgo: function timeAgo(time) {
      var between = Math.trunc((new Date().getTime() - time) / 1000);

      if (between < 3600) {
        return this.$tc('comment.minutes', Math.trunc(between / 60));
      } else if (between < 86400) {
        return this.$tc('comment.hours', Math.trunc(between / 3600));
      } else if (between < 2592000) {
        return this.$tc('comment.days', Math.trunc(between / 86400));
      } else if (between < 31104000) {
        return this.$tc('comment.months', Math.trunc(between / 2592000));
      } else {
        return this.$tc('comment.years', Math.trunc(between / 311004000));
      }
    },
    scroll2Anchor: function scroll2Anchor() {
      // const currentPage = this.$route.fullpath
      var target = this.$route.hash;

      if (target) {
        console.log(this.$refs);
        console.log(this.$route);
        console.log(target);
        console.log(target.match(/(?:#)(.+)/)[1]);
        var element = this.$refs[target.match(/(?:#)(.+)/)[1]]; // let element = this.$el.querySelector(target)
        // let element = this.$el
        // if (target.match(/(?:#)(.+)/)[1] === 'comments') element = this.$refs.comments

        console.log(element);

        if (element) {
          var scrollOptions = {
            top: element.offsetTop - this.navbarHeight,
            left: 0,
            behavior: 'smooth'
          };
          window.scrollTo(scrollOptions);
          window.history.pushState("object or string", "Title", this.$route.path);
        }
      }
    }
  },
  mounted: function mounted() {
    console.log("".concat(this.type, " ").concat(this.item.id));
    if (this.$route.hash && this.item.id === parseInt(this.$route.hash.match(/(?:#comment)(.+)/)[1])) this.scroll2Anchor(); // if (this.type === 'comment' && this.item.id === this.lastCommentId) {
    //   console.log('all comments mounted')
    //   console.log(this.$route)
    //   this.$emit('lastCommentMounted', true)
    // }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/comments/Show.vue?vue&type=template&id=45d040de&":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/comments/Show.vue?vue&type=template&id=45d040de& ***!
  \**********************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      ref: _vm.type + _vm.item.id,
      staticClass: "mt-3 mb-2",
      attrs: { id: "comment" + _vm.item.id }
    },
    [
      _c(
        "div",
        { staticClass: "d-flex align-items-center" },
        [
          _c("img", {
            staticClass: "rounded-circle",
            attrs: {
              src: _vm.item.user.image.thumb.url,
              alt: _vm.item.user.name,
              width: "24",
              height: "24"
            }
          }),
          _vm._v(" "),
          _c(
            "router-link",
            {
              staticClass: "mx-2 text-capitalize text-body",
              staticStyle: { "font-size": "90%" },
              attrs: { to: "/u/" + _vm.item.user.slug }
            },
            [_vm._v(_vm._s(_vm.item.user.name))]
          ),
          _vm._v(" "),
          _c("small", { staticClass: "text-muted" }, [
            _vm._v(_vm._s(_vm.timeAgo(_vm.item.timestamp)))
          ])
        ],
        1
      ),
      _vm._v(" "),
      _vm.edit
        ? _c(
            "div",
            [
              _c("comment-form", {
                attrs: {
                  item: _vm.item,
                  actionAttr: _vm.editActionAttr(),
                  text: _vm.item.content
                },
                on: {
                  commentEditResponse: _vm.commentEditResponse,
                  commentDrop: _vm.commentDrop
                }
              })
            ],
            1
          )
        : _c(
            "div",
            { staticClass: "mt-2 bg-light rounded p-3" },
            [
              _c("vue-markdown", {
                staticClass: "text-break",
                attrs: { source: _vm.item.content }
              })
            ],
            1
          ),
      _vm._v(" "),
      _vm.isAuthenticated
        ? _c(
            "div",
            { staticClass: "mt-2 d-flex align-items-center" },
            [
              _c("comment-like", { attrs: { item: _vm.item, type: _vm.type } }),
              _vm._v(" "),
              _vm.item.user.id === _vm.currentUser.id
                ? _c(
                    "div",
                    {
                      staticClass: "d-flex text-muted mx-2 mouse-pointer",
                      on: { click: _vm.commentEdit }
                    },
                    [
                      _c("span", { staticClass: "material-icons md-16" }, [
                        _vm._v("edit")
                      ])
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.item.user.id === _vm.currentUser.id
                ? _c(
                    "div",
                    {
                      staticClass: "d-flex text-muted mx-2 mouse-pointer",
                      on: { click: _vm.commentDestroy }
                    },
                    [
                      _c("span", { staticClass: "material-icons md-16" }, [
                        _vm._v("delete")
                      ])
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              _c(
                "div",
                {
                  staticClass: "d-flex text-muted mx-2 mouse-pointer",
                  on: { click: _vm.commentReply }
                },
                [
                  _c("span", { staticClass: "material-icons md-16" }, [
                    _vm._v("reply")
                  ])
                ]
              )
            ],
            1
          )
        : _vm._e(),
      _vm._v(" "),
      _vm.reply
        ? _c(
            "div",
            [
              _c("comment-form", {
                attrs: { item: _vm.item, actionAttr: "REPLY_NEW", text: null },
                on: {
                  commentReplyNew: _vm.commentReplyNew,
                  commentDrop: _vm.commentDrop
                }
              })
            ],
            1
          )
        : _vm._e()
    ]
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=36-4aedc841f3d757f8e313.chunk.js.map