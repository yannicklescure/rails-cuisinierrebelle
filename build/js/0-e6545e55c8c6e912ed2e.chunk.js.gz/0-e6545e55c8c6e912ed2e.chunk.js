(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[0],{

/***/ "./app/javascript/vue/components/Card.vue":
/*!************************************************!*\
  !*** ./app/javascript/vue/components/Card.vue ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Card_vue_vue_type_template_id_3929261a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Card.vue?vue&type=template&id=3929261a& */ "./app/javascript/vue/components/Card.vue?vue&type=template&id=3929261a&");
/* harmony import */ var _Card_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Card.vue?vue&type=script&lang=js& */ "./app/javascript/vue/components/Card.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Card_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Card_vue_vue_type_template_id_3929261a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Card_vue_vue_type_template_id_3929261a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/components/Card.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/components/Card.vue?vue&type=script&lang=js&":
/*!*************************************************************************!*\
  !*** ./app/javascript/vue/components/Card.vue?vue&type=script&lang=js& ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Card_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib??ref--6-0!../../../../node_modules/vue-loader/lib??vue-loader-options!./Card.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/Card.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Card_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/components/Card.vue?vue&type=template&id=3929261a&":
/*!*******************************************************************************!*\
  !*** ./app/javascript/vue/components/Card.vue?vue&type=template&id=3929261a& ***!
  \*******************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Card_vue_vue_type_template_id_3929261a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib??vue-loader-options!./Card.vue?vue&type=template&id=3929261a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/Card.vue?vue&type=template&id=3929261a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Card_vue_vue_type_template_id_3929261a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Card_vue_vue_type_template_id_3929261a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/Card.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/Card.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var mobile_device_detect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mobile-device-detect */ "./node_modules/mobile-device-detect/dist/index.js");
/* harmony import */ var mobile_device_detect__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mobile_device_detect__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
 // import Bookmark from '../components/buttons/Bookmark.vue'
// import Comment from '../components/buttons/Comment.vue'
// import Like from '../components/buttons/Like.vue'
// import Share from '../components/buttons/Share.vue'
// import Visit from '../components/buttons/Visit.vue'

var Bookmark = function Bookmark() {
  return __webpack_require__.e(/*! import() */ 4).then(__webpack_require__.bind(null, /*! ../components/buttons/Bookmark.vue */ "./app/javascript/vue/components/buttons/Bookmark.vue"));
};

var Comment = function Comment() {
  return __webpack_require__.e(/*! import() */ 5).then(__webpack_require__.bind(null, /*! ../components/buttons/Comment.vue */ "./app/javascript/vue/components/buttons/Comment.vue"));
};

var Like = function Like() {
  return __webpack_require__.e(/*! import() */ 6).then(__webpack_require__.bind(null, /*! ../components/buttons/Like.vue */ "./app/javascript/vue/components/buttons/Like.vue"));
};

var Share = function Share() {
  return __webpack_require__.e(/*! import() */ 7).then(__webpack_require__.bind(null, /*! ../components/buttons/Share.vue */ "./app/javascript/vue/components/buttons/Share.vue"));
};

var Visit = function Visit() {
  return __webpack_require__.e(/*! import() */ 8).then(__webpack_require__.bind(null, /*! ../components/buttons/Visit.vue */ "./app/javascript/vue/components/buttons/Visit.vue"));
};

/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'card',
  props: ['item'],
  components: {
    Bookmark: Bookmark,
    Comment: Comment,
    Like: Like,
    Share: Share,
    Visit: Visit
  },
  data: function data() {
    return {// truncate: true,
      // footer: true,
      // busy: false,
      // loading: true,
    };
  },
  computed: {
    mobile: function mobile() {
      return mobile_device_detect__WEBPACK_IMPORTED_MODULE_0__["isMobile"];
    }
  },
  methods: {
    heartFillBig: function heartFillBig() {
      var _this = this;

      console.log('liked');
      this.$refs.heartFillBig.innerHTML = '<i class="material-icons md-96 text-danger">favorite</i>';
      setTimeout(function () {
        _this.$refs.heartFillBig.innerHTML = '';
      }, 1000);
    },
    bookmarkFillBig: function bookmarkFillBig() {
      var _this2 = this;

      console.log('liked');
      this.$refs.bookmarkFillBig.innerHTML = '<i class="material-icons md-96 text-body">bookmark</i>';
      setTimeout(function () {
        _this2.$refs.bookmarkFillBig.innerHTML = '';
      }, 1000);
    } // itemReadyLog (value) {
    //   if (value === this.items[this.items.length-1].id) {
    //     console.log(this.items[this.items.length-1].id)
    //     console.log(value)
    //     this.$emit('listReady', value)
    //   }
    // },
    // forwardItem ({ data, page }) {
    //   console.log(data)
    //   let post = {}
    //   // this.data.splice(position, 1)
    //   if (data.create) {
    //     post = data.post
    //     post.comments = []
    //     post.forwards = []
    //     post.points = 0
    //     post.forward = data.parent
    //     // this.data.splice(0, 0, post)
    //     this.data.unshift(post)
    //   }
    //   else {
    //     post = this.data.filter(item => item.id === parseInt(data.post.id))[0]
    //     const position = this.data.indexOf(post)
    //     this.data.splice(position, 1)
    //   }
    //   this.$emit('updateFeed', this.data)
    // },
    // deleteItem (value) {
    //   console.log(value)
    //   const post = this.data.filter(item => item.id === parseInt(value.postId))[0]
    //   const position = this.data.indexOf(post)
    //   this.data.splice(position, 1)
    //   this.$emit('updateFeed', this.data)
    //   // const itemForwardBtn = document.querySelector(`#item-forward-btn-${value.parentId}`)
    //   // itemForwardBtn.classList.remove('text-primary')
    //   // itemForwardBtn.classList.add('text-secondary')
    //   // const itemForwardBtnCounter = document.querySelector(`#item-forward-btn-${value.parentId}-counter`)
    //   // let ifbcVal = parseInt(itemForwardBtnCounter.innerText)
    //   // itemForwardBtnCounter.innerText = ifbcVal - 1
    // },
    // editItem ({ post }) {
    //   const element = this.data.filter(item => item.id === parseInt(post.id))[0]
    //   const position = this.data.indexOf(element)
    //   this.data.splice(position, 1, post)
    //   this.$emit('updateFeed', this.data)
    // },
    // pinPost (value) {
    //   console.log('pinPost')
    //   console.log(value)
    //   this.$emit('pinPost', value)
    // }

  },
  mounted: function mounted() {
    this.$nextTick(function () {
      // this.loading = false
      console.log('card ready'); // this.$emit('cardParams', {
      //   params: {
      //     height: this.$refs[`card${this.item.recipe.id}`].offsetHeight,
      //     width: this.$refs[`card${this.item.recipe.id}`].offsetWidth
      //   }
      // })
    });
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/Card.vue?vue&type=template&id=3929261a&":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/Card.vue?vue&type=template&id=3929261a& ***!
  \*************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { ref: "card" + _vm.item.recipe.id }, [
    _c(
      "div",
      { staticClass: "card-header bg-white px-0 px-md-2 pt-2 pb-0 border-0" },
      [
        _c(
          "div",
          { staticClass: "d-flex justify-content-start align-items-center" },
          [
            _c("img", {
              directives: [
                {
                  name: "lazy",
                  rawName: "v-lazy",
                  value: _vm.item.user.image.thumb.url,
                  expression: "item.user.image.thumb.url"
                }
              ],
              staticClass: "rounded-circle mr-2",
              staticStyle: { "object-fit": "cover" },
              attrs: { width: "24px", height: "24px" }
            }),
            _vm._v(" "),
            _c(
              "router-link",
              {
                staticClass: "text-body d-flex align-items-center",
                staticStyle: { "font-size": "90%" },
                attrs: { to: "/u/" + _vm.item.user.slug }
              },
              [
                _c("div", { staticClass: "text-capitalize" }, [
                  _vm._v(_vm._s(_vm.item.user.name))
                ])
              ]
            ),
            _vm._v(" "),
            _vm.item.user.checked
              ? _c(
                  "span",
                  {
                    staticClass: "d-flex px-1",
                    attrs: {
                      "data-toggle": "tooltip",
                      "data-placement": "top",
                      title: "Verified"
                    }
                  },
                  [
                    _c("i", { staticClass: "material-icons md-16" }, [
                      _vm._v("check_circle")
                    ])
                  ]
                )
              : _vm._e()
          ],
          1
        )
      ]
    ),
    _vm._v(" "),
    _c(
      "div",
      { staticClass: "card-body bg-white px-0 px-md-2 py-2" },
      [
        _c("router-link", { attrs: { to: "/r/" + _vm.item.recipe.slug } }, [
          _c(
            "div",
            {
              class: [
                "card-img-top d-flex justify-content-center align-items-center"
              ],
              style: {
                backgroundImage: "url(" + _vm.item.recipe.photo.card.url + ")"
              }
            },
            [
              _c("div", { ref: "heartFillBig" }),
              _vm._v(" "),
              _c("div", { ref: "bookmarkFillBig" })
            ]
          )
        ]),
        _vm._v(" "),
        _c(
          "div",
          {
            staticClass:
              "d-flex justify-content-between align-items-center my-2"
          },
          [
            _c(
              "div",
              {
                class: [
                  "d-flex justify-content-between",
                  _vm.mobile ? "align-items-start" : "align-items-center ml-n2"
                ]
              },
              [
                _c("like", {
                  attrs: { item: _vm.item },
                  on: { liked: _vm.heartFillBig }
                }),
                _vm._v(" "),
                _c("comment", { attrs: { item: _vm.item } }),
                _vm._v(" "),
                _c("share", { attrs: { item: _vm.item } })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                class: [
                  "d-flex",
                  _vm.mobile ? "align-items-start" : "align-items-center"
                ]
              },
              [
                _c("visit", { attrs: { item: _vm.item } }),
                _vm._v(" "),
                _c("bookmark", {
                  attrs: { item: _vm.item },
                  on: { bookmarked: _vm.bookmarkFillBig }
                })
              ],
              1
            )
          ]
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "d-flex flex-column" },
          [
            _c(
              "router-link",
              {
                staticClass: "card-link text-body text-uppercase",
                attrs: { to: "/r/" + _vm.item.recipe.slug }
              },
              [
                _vm._v(
                  "\n        " + _vm._s(_vm.item.recipe.title) + "\n      "
                )
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "card-text font-weight-lighter",
                staticStyle: { "font-size": "90%" }
              },
              [
                _vm._v(
                  "\n        " +
                    _vm._s(_vm.item.recipe.description) +
                    "\n      "
                )
              ]
            )
          ],
          1
        )
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=0-e6545e55c8c6e912ed2e.chunk.js.map