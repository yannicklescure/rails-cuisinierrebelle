(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[33],{

/***/ "./app/javascript/vue/components/buttons/SocialSharing.vue":
/*!*****************************************************************!*\
  !*** ./app/javascript/vue/components/buttons/SocialSharing.vue ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SocialSharing_vue_vue_type_template_id_a2e472f2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SocialSharing.vue?vue&type=template&id=a2e472f2& */ "./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=template&id=a2e472f2&");
/* harmony import */ var _SocialSharing_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SocialSharing.vue?vue&type=script&lang=js& */ "./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _SocialSharing_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _SocialSharing_vue_vue_type_template_id_a2e472f2___WEBPACK_IMPORTED_MODULE_0__["render"],
  _SocialSharing_vue_vue_type_template_id_a2e472f2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "app/javascript/vue/components/buttons/SocialSharing.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=script&lang=js&":
/*!******************************************************************************************!*\
  !*** ./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialSharing_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--6-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SocialSharing.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_6_0_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialSharing_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=template&id=a2e472f2&":
/*!************************************************************************************************!*\
  !*** ./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=template&id=a2e472f2& ***!
  \************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialSharing_vue_vue_type_template_id_a2e472f2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./SocialSharing.vue?vue&type=template&id=a2e472f2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=template&id=a2e472f2&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialSharing_vue_vue_type_template_id_a2e472f2___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_SocialSharing_vue_vue_type_template_id_a2e472f2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--6-0!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _fortawesome_vue_fontawesome__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @fortawesome/vue-fontawesome */ "./node_modules/@fortawesome/vue-fontawesome/index.es.js");
/* harmony import */ var _fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @fortawesome/fontawesome-svg-core */ "./node_modules/@fortawesome/fontawesome-svg-core/index.es.js");
/* harmony import */ var _fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fortawesome/free-regular-svg-icons */ "./node_modules/@fortawesome/free-regular-svg-icons/index.es.js");
/* harmony import */ var _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @fortawesome/free-brands-svg-icons */ "./node_modules/@fortawesome/free-brands-svg-icons/index.es.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




_fortawesome_fontawesome_svg_core__WEBPACK_IMPORTED_MODULE_1__["library"].add(_fortawesome_free_regular_svg_icons__WEBPACK_IMPORTED_MODULE_2__["faEnvelope"], _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faFacebookF"], _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faTelegramPlane"], _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faTwitter"], _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faVk"], _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_3__["faWhatsapp"]);
/* harmony default export */ __webpack_exports__["default"] = ({
  name: 'SocialSharing',
  props: ['item'],
  components: {
    FontAwesomeIcon: _fortawesome_vue_fontawesome__WEBPACK_IMPORTED_MODULE_0__["FontAwesomeIcon"],
    FontAwesomeLayers: _fortawesome_vue_fontawesome__WEBPACK_IMPORTED_MODULE_0__["FontAwesomeLayers"]
  },
  data: function data() {
    return {
      sharing: {
        url: "".concat(window.location.origin, "/r/").concat(this.item.recipe.slug),
        title: '',
        description: '',
        // quote: 'The hot reload is so fast it\'s near instant. - Evan You',
        hashtags: "CuisinierRebelle,".concat(this.item.user.slug) // twitterUser: ''

      },
      networks: [{
        network: 'email',
        name: 'Email',
        icon: ['far', 'envelope'],
        color: '#333333'
      }, {
        network: 'facebook',
        name: 'Facebook',
        icon: ['fab', 'facebook-f'],
        color: '#1877f2'
      }, {
        network: 'telegram',
        name: 'Telegram',
        icon: ['fab', 'telegram-plane'],
        color: '#0088cc'
      }, {
        network: 'twitter',
        name: 'Twitter',
        icon: ['fab', 'twitter'],
        color: '#1da1f2'
      }, {
        network: 'vk',
        name: 'Vk',
        icon: ['fab', 'vk'],
        color: '#4a76a8'
      }, {
        network: 'whatsapp',
        name: 'Whatsapp',
        icon: ['fab', 'whatsapp'],
        color: '#25d366'
      }]
    };
  },
  beforeMount: function beforeMount() {
    this.fixSharingData();
  },
  methods: {
    fixSharingData: function fixSharingData() {
      this.sharing.title = this.item.recipe.title ? this.item.recipe.title : 'Cuisinier Rebelle'; // if (this.item.content === null) this.item.content = ''

      this.sharing.description = this.item.recipe.description.length >= 200 ? "".concat(this.item.recipe.description.substring(0, 197), "...") : this.item.recipe.description;
    }
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=template&id=a2e472f2&":
/*!******************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./app/javascript/vue/components/buttons/SocialSharing.vue?vue&type=template&id=a2e472f2& ***!
  \******************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass:
        "d-flex flex-column flex-md-row justify-content-center justify-content-md-center"
    },
    _vm._l(_vm.networks, function(network) {
      return _c(
        "ShareNetwork",
        {
          key: network.network,
          staticClass: "mouse-pointer btn m-2 text-white d-flex flex-column",
          attrs: {
            network: network.network,
            url: _vm.sharing.url,
            title: _vm.sharing.title,
            description: _vm.sharing.description,
            quote: _vm.sharing.quote,
            hashtags: _vm.sharing.hashtags,
            twitterUser: _vm.sharing.twitterUser
          }
        },
        [
          _c(
            "div",
            {
              staticClass:
                "d-flex justify-content-center align-items-center rounded rounded-circle mb-2",
              style: "width:64px;height:64px;backgroundColor: " + network.color
            },
            [
              _c(
                "font-awesome-layers",
                { staticClass: "fa-lg" },
                [_c("font-awesome-icon", { attrs: { icon: network.icon } })],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c("span", { staticClass: "text-body" }, [
            _vm._v(_vm._s(network.name))
          ])
        ]
      )
    }),
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ })

}]);
//# sourceMappingURL=33-933fc76505d9f72c1153.chunk.js.map